import Foundation

// MARK: - NetworkModels
/// نماذج نتائج الفحص — كلها بيانات مقروءة فقط، بلا أي استنتاج مخترع.
/// v1.1: سرد كل الواجهات، مرشحو بوابة متعددون، عقبات مسجلة، نتائج SSDP وTLS وتتبع.

/// واجهة شبكة واحدة كما تظهر في getifaddrs.
struct InterfaceInfo: Identifiable {
    let id = UUID()
    let name: String
    let ip: String?
    let netmask: String?
    let isUp: Bool
    /// الواجهة النشطة المختارة للفحص (عادة en0).
    let isActive: Bool

    var kindLabelAr: String {
        switch name {
        case "en0": return "Wi-Fi"
        case "awdl0": return "AWDL (AirDrop)"
        case "pdp_ip0": return "بيانات خلوية"
        case "lo0": return "محلية (loopback)"
        default:
            if name.hasPrefix("en") { return "إيثرنت/Wi-Fi" }
            if name.hasPrefix("pdp_ip") { return "بيانات خلوية" }
            if name.hasPrefix("utun") { return "نفق VPN" }
            return "أخرى"
        }
    }
}

/// معلومات الشبكة الحالية كما تقرأها iOS فعلياً.
struct NetworkInfo {
    /// اسم الشبكة — قد يكون nil لأن iOS تمنع قراءته بلا صلاحية Wi-Fi.
    var ssid: String?
    /// هل سُمح بقراءة SSID أصلاً (false تعني «غير متاح من iOS»).
    var ssidAvailable: Bool
    /// عنوان MAC لنقطة الوصول (BSSID) — قد يكون nil لنفس قيد SSID.
    var bssid: String?
    var localIP: String?
    var netmask: String?
    var interfaceName: String?
    /// كل الواجهات المقروءة (en0 وawdl0 وpdp_ip0 وغيرها).
    var interfaces: [InterfaceInfo] = []
    var gateway: String?
    var gatewaySource: GatewaySource
    /// كل مرشحي البوابة مع حالة ردّ كل منهم.
    var gatewayCandidates: [GatewayCandidate] = []
    var dnsServers: [String]
    var isWiFi: Bool
    var isDemo: Bool

    static var empty: NetworkInfo {
        NetworkInfo(ssid: nil, ssidAvailable: false, bssid: nil, localIP: nil, netmask: nil,
                    interfaceName: nil, interfaces: [], gateway: nil, gatewaySource: .unavailable,
                    gatewayCandidates: [], dnsServers: [], isWiFi: false, isDemo: false)
    }
}

enum GatewaySource: String {
    /// مؤكدة بردّ مباشر من العنوان نفسه (ping أو TCP).
    case system
    case heuristic
    case unavailable

    var labelAr: String {
        switch self {
        case .system: return "مؤكدة بردّ مباشر"
        case .heuristic: return "مرجّحة (من النطاق، بلا ردّ مؤكد)"
        case .unavailable: return "غير متاحة"
        }
    }
}

/// مرشح بوابة واحد مع مصدره وحالة ردّه.
struct GatewayCandidate: Identifiable {
    let id = UUID()
    let ip: String
    /// مصدر الترشيح: "نطاق .1" أو "نطاق .254" أو "DHCP".
    let source: String
    var responded: Bool
    var rttMs: Double?
    var isDemo: Bool

    var labelAr: String {
        responded ? "ردّ" : "بلا ردّ"
    }
}

/// حالة إذن الشبكة المحلية كما تُستدل من عمل البحث نفسه.
/// ملاحظة صريحة: iOS لا توفر واجهة برمجية مباشرة لسؤال الإذن؛
/// الحالة هنا مستدلة: «ممنوح» إن عمل البحث، «مرفوض» إن فشل البحث
/// بخطأ إذن، و«لم يُطلب بعد» قبل أول محاولة بحث.
enum LocalNetworkPermission: String {
    case notRequested
    case granted
    case denied
    case unknown

    var labelAr: String {
        switch self {
        case .notRequested: return "لم يُطلب بعد"
        case .granted: return "ممنوح (يعمل البحث)"
        case .denied: return "مرفوض — يمنع كل الفحص"
        case .unknown: return "غير معروف"
        }
    }
}

/// عقبة تمنع خطوة فحص — تُسجَّل مع سببها المحتمل وإصلاحها المقترح،
/// وتظهر في الخلاصة والسجل وتُضمَّن في التصدير.
struct Obstacle: Identifiable, Codable {
    let id: UUID
    let date: Date
    let category: String
    let title: String
    let cause: String
    let fix: String
    let isDemo: Bool

    init(category: String, title: String, cause: String, fix: String, isDemo: Bool = false) {
        self.id = UUID()
        self.date = Date()
        self.category = category
        self.title = title
        self.cause = cause
        self.fix = fix
        self.isDemo = isDemo
    }
}

/// جهاز ردّ على الفحص في النطاق المحلي.
struct DiscoveredHost: Identifiable {
    let id = UUID()
    let ip: String
    let rttMs: Double?
    /// طريقة الاكتشاف: "ICMP ping" أو "TCP:80" (بديل عند تعذر ICMP).
    let method: String
    let isGateway: Bool
    /// اسم المضيف من بحث DNS العكسي — nil إن لم يُحلّ.
    let hostname: String?
    let isDemo: Bool
}

enum PortState: String, Codable {
    case open
    case closed
    case timeout

    var labelAr: String {
        switch self {
        case .open: return "مفتوح"
        case .closed: return "مغلق"
        case .timeout: return "لا رد (مصفّى/مهلة)"
        }
    }
}

/// نتيجة فحص منفذ TCP واحد.
struct PortResult: Identifiable {
    let id = UUID()
    let host: String
    let port: Int
    let state: PortState
    /// لافتة الخدمة كما وردت (مقتطعة) — nil إن لم ترد.
    let banner: String?
    /// اسم الخدمة المعروفة للمنفذ (مثل AirPlay للمنفذ 7000) — nil إن غير معروفة.
    let serviceName: String?
    let isDemo: Bool
}

/// خدمة Bonjour مكتشفة.
struct BonjourServiceInfo: Identifiable {
    let id = UUID()
    let name: String
    let type: String
    let host: String
    let port: Int
    let isDemo: Bool
}

/// خدمة SSDP/UPnP مكتشفة من رد M-SEARCH.
struct SsdpServiceInfo: Identifiable {
    let id = UUID()
    let location: String
    let server: String
    let usn: String
    let searchTarget: String
    let sourceIP: String
    let isDemo: Bool
}

/// شهادة TLS كما قُرئت من المصافحة فقط (بلا اتصال كامل ولا دخول).
struct TlsCertificateInfo: Identifiable {
    let id = UUID()
    let host: String
    let port: Int
    let subject: String
    let issuer: String
    let expiresAt: String
    let fingerprintSHA256: String
    let isDemo: Bool
}

/// قفزة واحدة في تتبع المسار.
struct TraceHop: Identifiable {
    let id = UUID()
    let ttl: Int
    let ip: String?
    let rttMs: Double?
    let isDemo: Bool

    var statusAr: String {
        if let ip {
            return ip
        }
        return "لا يرد"
    }
}

/// نتيجة فحص HTTP لمنفذ مفتوح.
struct HttpProbeResult: Identifiable {
    let id = UUID()
    let url: String
    let path: String
    let method: String
    let statusCode: Int?
    let headers: [(String, String)]
    let bodyPrefix: String
    /// طرق HTTP المسموحة من رد OPTIONS — nil إن لم تُطلب.
    let allowedMethods: String?
    let error: String?
    let isDemo: Bool
}
