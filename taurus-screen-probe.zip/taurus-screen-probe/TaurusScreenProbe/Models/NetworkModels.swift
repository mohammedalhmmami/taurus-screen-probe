import Foundation

// MARK: - NetworkModels
/// نماذج نتائج الفحص — كلها بيانات مقروءة فقط، بلا أي استنتاج مخترع.

/// معلومات الشبكة الحالية كما تقرأها iOS فعلياً.
struct NetworkInfo {
    /// اسم الشبكة — قد يكون nil لأن iOS تمنع قراءته بلا صلاحية Wi-Fi.
    var ssid: String?
    /// هل سُمح بقراءة SSID أصلاً (false تعني «غير متاح من iOS»).
    var ssidAvailable: Bool
    var localIP: String?
    var netmask: String?
    var interfaceName: String?
    var gateway: String?
    var gatewaySource: GatewaySource
    var dnsServers: [String]
    var isWiFi: Bool
    var isDemo: Bool

    static var empty: NetworkInfo {
        NetworkInfo(ssid: nil, ssidAvailable: false, localIP: nil, netmask: nil,
                    interfaceName: nil, gateway: nil, gatewaySource: .unavailable,
                    dnsServers: [], isWiFi: false, isDemo: false)
    }
}

enum GatewaySource: String {
    case system
    case heuristic
    case unavailable

    var labelAr: String {
        switch self {
        case .system: return "مقروءة من جدول التوجيه"
        case .heuristic: return "مرجّحة (أول عنوان في النطاق)"
        case .unavailable: return "غير متاحة"
        }
    }
}

/// جهاز ردّ على الفحص في النطاق المحلي.
struct DiscoveredHost: Identifiable {
    let id = UUID()
    let ip: String
    let rttMs: Double?
    /// طريقة الاكتشاف: "ICMP ping" أو "TCP:80" (بديل عند تعذر ICMP).
    let method: String
    let isGateway: Bool
    let isDemo: Bool
}

enum PortState: String, Codable {
    case open
    case closed
    case timeout

    var labelAr: String {
        switch self {
        case .open: return "مفتوح"
        case .closed: return "مغلق"
        case .timeout: return "لا رد (مصفّى/مهلة)"
        }
    }
}

/// نتيجة فحص منفذ TCP واحد.
struct PortResult: Identifiable {
    let id = UUID()
    let host: String
    let port: Int
    let state: PortState
    /// لافتة الخدمة كما وردت (مقتطعة) — nil إن لم ترد.
    let banner: String?
    let isDemo: Bool
}

/// خدمة Bonjour مكتشفة.
struct BonjourServiceInfo: Identifiable {
    let id = UUID()
    let name: String
    let type: String
    let host: String
    let port: Int
    let isDemo: Bool
}

/// نتيجة فحص HTTP لمنفذ مفتوح.
struct HttpProbeResult: Identifiable {
    let id = UUID()
    let url: String
    let statusCode: Int?
    let headers: [(String, String)]
    let bodyPrefix: String
    let error: String?
    let isDemo: Bool
}
