import Foundation

// MARK: - ProbeLog
/// سجل الفحص — كل خطوة فحص تُسجَّل بوقتها وفئتها ونتيجتها الخام.
/// يُصدَّر نصاً وJSON من شاشة السجل لإرساله إلى المطوّر.

enum ProbeLogLevel: String, Codable, CaseIterable {
    case info
    case success
    case warning
    case error

    var labelAr: String {
        switch self {
        case .info: return "معلومة"
        case .success: return "نجاح"
        case .warning: return "تنبيه"
        case .error: return "خطأ"
        }
    }
}

struct ProbeLogEntry: Identifiable, Codable {
    let id: UUID
    let date: Date
    let level: ProbeLogLevel
    let category: String
    let message: String
    let detail: String

    init(level: ProbeLogLevel, category: String, message: String, detail: String = "") {
        self.id = UUID()
        self.date = Date()
        self.level = level
        self.category = category
        self.message = message
        self.detail = detail
    }
}

/// مخزن السجل — يُشارك بين كل الشاشات عبر ProbeState.
@MainActor
final class ProbeLogStore: ObservableObject {
    @Published private(set) var entries: [ProbeLogEntry] = []

    func add(_ level: ProbeLogLevel, category: String, message: String, detail: String = "") {
        entries.append(ProbeLogEntry(level: level, category: category, message: message, detail: detail))
    }

    func clear() {
        entries.removeAll()
    }

    /// نص التصدير — سطر لكل مدخل: الوقت + المستوى + الفئة + الرسالة + التفاصيل.
    func textExport() -> String {
        var lines: [String] = []
        lines.append("سجل فاحص شاشة تورس (Taurus Screen Probe)")
        lines.append("تاريخ التصدير: \(Date().formatted(date: .abbreviated, time: .standard))")
        lines.append("عدد المدخلات: \(entries.count)")
        lines.append(String(repeating: "=", count: 50))
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        for entry in entries {
            lines.append("[\(formatter.string(from: entry.date))] [\(entry.level.labelAr)] [\(entry.category)] \(entry.message)")
            if !entry.detail.isEmpty {
                lines.append("    \(entry.detail)")
            }
        }
        return lines.joined(separator: "\n")
    }

    /// نسخة JSON من السجل.
    func jsonExport() -> Data? {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        return try? encoder.encode(entries)
    }

    /// يحفظ نسختي التصدير في Documents ويعيد مساريهما.
    func exportFiles() -> (txt: URL, json: URL)? {
        guard let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
            return nil
        }
        let stamp = DateFormatter()
        stamp.dateFormat = "yyyyMMdd-HHmm"
        let base = "ScreenProbe-Log-\(stamp.string(from: Date()))"
        let txtURL = docs.appendingPathComponent("\(base).txt")
        let jsonURL = docs.appendingPathComponent("\(base).json")
        do {
            try textExport().write(to: txtURL, atomically: true, encoding: .utf8)
            if let data = jsonExport() {
                try data.write(to: jsonURL)
            } else {
                return nil
            }
            return (txtURL, jsonURL)
        } catch {
            return nil
        }
    }
}
