import Foundation

// MARK: - ProbeLog
/// سجل الفحص — كل خطوة فحص تُسجَّل بوقتها وفئتها ونتيجتها الخام.
/// يُصدَّر نصاً وJSON من شاشة السجل لإرساله إلى المطوّر.

enum ProbeLogLevel: String, Codable, CaseIterable {
    case info
    case success
    case warning
    case error

    var labelAr: String {
        switch self {
        case .info: return "معلومة"
        case .success: return "نجاح"
        case .warning: return "تنبيه"
        case .error: return "خطأ"
        }
    }
}

struct ProbeLogEntry: Identifiable, Codable {
    let id: UUID
    let date: Date
    let level: ProbeLogLevel
    let category: String
    let message: String
    let detail: String

    init(level: ProbeLogLevel, category: String, message: String, detail: String = "") {
        self.id = UUID()
        self.date = Date()
        self.level = level
        self.category = category
        self.message = message
        self.detail = detail
    }
}

/// مخزن السجل — يُشارك بين كل الشاشات عبر ProbeState.
@MainActor
final class ProbeLogStore: ObservableObject {
    @Published private(set) var entries: [ProbeLogEntry] = []

    func add(_ level: ProbeLogLevel, category: String, message: String, detail: String = "") {
        entries.append(ProbeLogEntry(level: level, category: category, message: message, detail: detail))
    }

    func clear() {
        entries.removeAll()
    }

    /// نص التصدير — سطر لكل مدخل: الوقت + المستوى + الفئة + الرسالة + التفاصيل،
    /// ثم قسم مخصص للعقبات (كل عقبة مع سببها وإصلاحها المقترح).
    func textExport(obstacles: [Obstacle] = []) -> String {
        var lines: [String] = []
        lines.append("سجل فاحص شاشة تورس (Taurus Screen Probe)")
        lines.append("تاريخ التصدير: \(Date().formatted(date: .abbreviated, time: .standard))")
        lines.append("عدد المدخلات: \(entries.count)")
        lines.append("عدد العقبات: \(obstacles.count)")
        lines.append(String(repeating: "=", count: 50))
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        for entry in entries {
            lines.append("[\(formatter.string(from: entry.date))] [\(entry.level.labelAr)] [\(entry.category)] \(entry.message)")
            if !entry.detail.isEmpty {
                lines.append("    \(entry.detail)")
            }
        }
        lines.append("")
        lines.append(String(repeating: "=", count: 50))
        lines.append("العقبات (\(obstacles.count)) — ما منع الفحص وأين توقف:")
        if obstacles.isEmpty {
            lines.append("لا عقبات مسجلة.")
        }
        for obstacle in obstacles {
            lines.append("[\(formatter.string(from: obstacle.date))] [\(obstacle.category)] \(obstacle.title)\(obstacle.isDemo ? " (تجريبي)" : "")")
            lines.append("    السبب المحتمل: \(obstacle.cause)")
            lines.append("    الإصلاح المقترح: \(obstacle.fix)")
        }
        return lines.joined(separator: "\n")
    }

    /// نسخة JSON من السجل مع العقبات.
    func jsonExport(obstacles: [Obstacle] = []) -> Data? {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        let payload = LogExportData(app: "Taurus Screen Probe", exportedAt: Date(), entries: entries, obstacles: obstacles)
        return try? encoder.encode(payload)
    }

    /// يحفظ نسختي التصدير في Documents ويعيد مساريهما.
    func exportFiles(obstacles: [Obstacle] = []) -> (txt: URL, json: URL)? {
        guard let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
            return nil
        }
        let stamp = DateFormatter()
        stamp.dateFormat = "yyyyMMdd-HHmm"
        let base = "ScreenProbe-Log-\(stamp.string(from: Date()))"
        let txtURL = docs.appendingPathComponent("\(base).txt")
        let jsonURL = docs.appendingPathComponent("\(base).json")
        do {
            try textExport(obstacles: obstacles).write(to: txtURL, atomically: true, encoding: .utf8)
            if let data = jsonExport(obstacles: obstacles) {
                try data.write(to: jsonURL)
            } else {
                return nil
            }
            return (txtURL, jsonURL)
        } catch {
            return nil
        }
    }
}

/// حمولة تصدير JSON — المدخلات + العقبات معاً.
private struct LogExportData: Codable {
    let app: String
    let exportedAt: Date
    let entries: [ProbeLogEntry]
    let obstacles: [Obstacle]
}
