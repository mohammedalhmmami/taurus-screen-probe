import Combine
import Foundation

// MARK: - ProbeState
/// الحالة العامة للتطبيق — كل الشاشات تقرأ منها.
/// قراءة فقط: لا كتابة في السيارة ولا محاولات دخول ولا تخمين كلمات مرور.

struct SummaryStatement {
    enum Kind { case fact, conclusion, warning }
    let kind: Kind
    let text: String
}

@MainActor
final class ProbeState: ObservableObject {
    @Published var network: NetworkInfo = .empty
    @Published var hosts: [DiscoveredHost] = []
    @Published var portResults: [PortResult] = []
    @Published var httpResults: [HttpProbeResult] = []
    @Published var demoMode = false
    @Published var isScanning = false
    @Published var scanStatus = ""

    /// الوضع التجريبي: تصفح وفحص وهمي بلا سيارة — كل نتيجة موسومة تجريبي.
    @Published var hasScanned = false

    let log = ProbeLogStore()
    let pathWatcher = PathWatcher()
    let bonjour = BonjourScanner()

    let ping = PingService()
    let portScan = PortScanService()
    let http = HttpProbeService()

    private var cancellables = Set<AnyCancellable>()

    init() {
        // تمرير تغيّرات الماسح المتداخل إلى الواجهة (وإلا لا تتحدث القوائم).
        bonjour.objectWillChange.sink { [weak self] _ in
            self?.objectWillChange.send()
        }.store(in: &cancellables)
    }

    /// المنافذ المفحوصة على كل جهاز يرد.
    let commonPorts = [80, 443, 8080, 53, 22, 23, 5000, 7000, 8000, 8443, 49152, 49153, 7001, 7100, 5353]
    /// منافذ HTTP التي يُفحص محتواها بعد فتحها.
    let httpPorts: Set<Int> = [80, 8080, 8000, 8888, 7000, 5000, 8443]
    /// أنواع خدمات Bonjour المبحوث عنها.
    let bonjourTypes = ["_airplay._tcp.", "_raop._tcp.", "_http._tcp.", "_ipp._tcp.",
                        "_printer._tcp.", "_googlecast._tcp.", "_companion-link._tcp.", "_dacp._tcp."]

    var openPorts: [PortResult] {
        portResults.filter { $0.state == .open }
    }

    var discoveredIPs: [String] {
        hosts.map { $0.ip }
    }

    // MARK: - الخلاصة (مبنية على النتائج المسجلة فقط)

    var summaryStatements: [SummaryStatement] {
        var out: [SummaryStatement] = []
        if demoMode {
            out.append(SummaryStatement(kind: .warning, text: "وضع تجريبي — كل النتائج أدناه وهمية وليست من شبكة سيارة."))
        }
        if !hasScanned {
            out.append(SummaryStatement(kind: .fact, text: "لم يُجرَ أي فحص بعد — شغّل «فحص شامل» من الشاشة الرئيسية."))
            return out
        }
        if hosts.isEmpty {
            out.append(SummaryStatement(kind: .conclusion, text: "لم يرد أي جهاز على الفحص — تأكد أن الآيفون متصل بشبكة الشاشة فعلاً وأن الفحص جرى أثناء بثها."))
            return out
        }
        out.append(SummaryStatement(kind: .fact, text: "رُصد \(hosts.count) جهازاً يرد على الشبكة: \(hosts.map { $0.ip }.joined(separator: ", "))."))
        if openPorts.isEmpty {
            out.append(SummaryStatement(kind: .conclusion, text: "لا توجد خدمات مكشوفة على هذه الشبكة — كل المنافذ المفحوصة (\(commonPorts.count) منفذاً) مغلقة أو بلا رد. لا يوجد ما يدل على بوابة تشخيص."))
        } else {
            let list = openPorts.map { "\($0.host):\($0.port)" }.joined(separator: ", ")
            out.append(SummaryStatement(kind: .fact, text: "منافذ مفتوحة: \(list)."))
            let mediaOnly = openPorts.allSatisfy { [7000, 7001, 7100, 8000, 8080, 80, 443].contains($0.port) }
                && !bonjour.services.isEmpty
                && bonjour.services.allSatisfy { $0.type.contains("airplay") || $0.type.contains("raop") }
            if mediaOnly {
                out.append(SummaryStatement(kind: .conclusion, text: "ما وُجد هو خدمات وسائط (AirPlay/RAOP) فقط — هذه شبكة وسائط للصوت والصورة، لا بوابة تشخيص لوحدات السيارة."))
            }
            if openPorts.contains(where: { $0.port == 22 || $0.port == 23 }) {
                out.append(SummaryStatement(kind: .warning, text: "وجدنا منفذ تحكم عن بعد مفتوحاً (SSH/Telnet) — نتيجة غير معتادة على شبكة سيارة؛ سُجلت كما وردت وتحتاج تحققاً مستقلاً قبل أي استنتاج."))
            }
            if openPorts.contains(where: { $0.port == 5000 || $0.port == 49152 || $0.port == 49153 }) {
                out.append(SummaryStatement(kind: .fact, text: "وجدنا منافذ خدمات شبكية (5000/49152) — قد تكون خدمات اكتشاف/وسائط؛ راجع لافتاتها في شاشة المنافذ."))
            }
        }
        if bonjour.services.isEmpty {
            out.append(SummaryStatement(kind: .fact, text: "لم تُكتشف أي خدمة Bonjour معلنة على الشبكة."))
        } else {
            out.append(SummaryStatement(kind: .fact, text: "خدمات Bonjour المكتشفة: \(bonjour.services.map { "\($0.name) (\($0.type))" }.joined(separator: "، "))."))
        }
        if !httpResults.isEmpty {
            let ok = httpResults.filter { $0.statusCode != nil }
            out.append(SummaryStatement(kind: .fact, text: "فحص HTTP: \(ok.count) من \(httpResults.count) منفذاً ردّ على طلب HTTP."))
        }
        out.append(SummaryStatement(kind: .conclusion, text: "هذا الملخص مبني على نتائج الفحص المسجلة فقط — لا استنتاج خارجها."))
        return out
    }
}
