import Combine
import Foundation

// MARK: - ProbeState
/// الحالة العامة للتطبيق — كل الشاشات تقرأ منها.
/// قراءة فقط: لا كتابة في السيارة ولا محاولات دخول ولا تخمين كلمات مرور.
/// v1.1: واجهات متعددة، مرشحو بوابة، عقبات، SSDP وTLS وتتبع، فحص منافذ كامل.

/// وضع فحص المنافذ: سريع (الشائعة) أو كامل (1–65535).
enum PortScanMode: String, CaseIterable {
    case quick
    case full

    var labelAr: String {
        switch self {
        case .quick: return "سريع (المنافذ الشائعة)"
        case .full: return "كامل (1–65535)"
        }
    }
}

struct SummaryStatement {
    enum Kind { case fact, conclusion, warning }
    let kind: Kind
    let text: String
}

@MainActor
final class ProbeState: ObservableObject {
    @Published var network: NetworkInfo = .empty
    @Published var hosts: [DiscoveredHost] = []
    @Published var portResults: [PortResult] = []
    @Published var httpResults: [HttpProbeResult] = []
    @Published var demoMode = false
    @Published var isScanning = false
    @Published var scanStatus = ""

    /// الوضع التجريبي: تصفح وفحص وهمي بلا سيارة — كل نتيجة موسومة تجريبي.
    @Published var hasScanned = false

    /// v1.1 — كل الواجهات المقروءة (بدل افتراض en0 وحدها).
    @Published var interfaces: [InterfaceInfo] = []
    /// v1.1 — مرشحو البوابة مع حالة ردّ كل منهم.
    @Published var gatewayCandidates: [GatewayCandidate] = []
    /// v1.1 — العقبات المسجلة (كل خطوة فاشلة مع سببها وإصلاحها).
    @Published var obstacles: [Obstacle] = []
    /// v1.1 — حالة إذن الشبكة المحلية (مستدلة من عمل البحث، لا واجهة مباشرة لها في iOS).
    @Published var localNetworkPermission: LocalNetworkPermission = .notRequested
    @Published var permissionErrorCode: Int?
    /// v1.1 — خدمات SSDP/UPnP المكتشفة.
    @Published var ssdpServices: [SsdpServiceInfo] = []
    /// v1.1 — شهادات TLS المقروءة من المصافحة.
    @Published var tlsResults: [TlsCertificateInfo] = []
    /// v1.1 — قفزات تتبع المسار إلى البوابة.
    @Published var traceHops: [TraceHop] = []
    /// v1.1 — أنواع خدمات DNS-SD المعلنة التي سُردت من _services._dns-sd._udp.
    @Published var discoveredServiceTypes: [String] = []
    /// v1.1 — وضع فحص المنافذ الحالي.
    @Published var portScanMode: PortScanMode = .quick
    /// v1.1 — إحصاء فحص المنافذ (في الوضع الكامل تُحفظ المفتوحة فقط).
    @Published var portScannedCount = 0
    @Published var portClosedCount = 0

    let log = ProbeLogStore()
    let pathWatcher = PathWatcher()
    let bonjour = BonjourScanner()

    let ping = PingService()
    let portScan = PortScanService()
    let http = HttpProbeService()
    let ssdp = SsdpService()
    let tls = TlsProbeService()
    let traceroute = TracerouteService()

    private var cancellables = Set<AnyCancellable>()

    init() {
        // تمرير تغيّرات الماسح المتداخل إلى الواجهة (وإلا لا تتحدث القوائم).
        bonjour.objectWillChange.sink { [weak self] _ in
            self?.objectWillChange.send()
        }.store(in: &cancellables)
    }

    /// المنافذ الشائعة في الوضع السريع.
    let commonPorts = [21, 22, 23, 53, 80, 443, 554, 631, 3689, 5000, 5223, 5900, 7000, 7001, 7100, 8000, 8008, 8009, 8080, 8443, 8888, 9090, 9100, 1900, 5353, 62078, 49152, 49153]
    /// منافذ HTTP التي يُفحص محتواها بعد فتحها.
    let httpPorts: Set<Int> = [80, 8080, 8000, 8888, 7000, 5000, 8443]
    /// مسارات HTTP الشائعة في الفحص الموسّع.
    let httpPaths = ["/", "/api", "/status", "/info", "/config", "/about", "/device", "/system"]
    /// أنواع خدمات Bonjour المبحوث عنها احتياطياً (قبل سرد المعلنة).
    let bonjourTypes = ["_airplay._tcp.", "_raop._tcp.", "_http._tcp.", "_https._tcp.", "_ipp._tcp.",
                        "_printer._tcp.", "_googlecast._tcp.", "_companion-link._tcp.", "_dacp._tcp.",
                        "_ssh._tcp.", "_device-info._tcp.", "_homekit._tcp."]

    var openPorts: [PortResult] {
        portResults.filter { $0.state == .open }
    }

    var discoveredIPs: [String] {
        hosts.map { $0.ip }
    }

    /// الجهاز المرجح أنه الشاشة: أول بوابة ردّت، وإلا أول جهاز ردّ بأقل IP.
    var likelyScreenDevice: DiscoveredHost? {
        if let gw = hosts.first(where: { $0.isGateway }) { return gw }
        return hosts.sorted { $0.ip < $1.ip }.first
    }

    /// يسجّل عقبة في القائمة وفي السجل معاً.
    func addObstacle(category: String, title: String, cause: String, fix: String, level: ProbeLogLevel = .warning, isDemo: Bool = false) {
        obstacles.append(Obstacle(category: category, title: title, cause: cause, fix: fix, isDemo: isDemo))
        log.add(level, category: category, message: "عقبة: \(title)", detail: "السبب: \(cause) — الإصلاح: \(fix)")
    }

    func clearObstacles() {
        obstacles.removeAll()
    }

    // MARK: - الخلاصة (مبنية على النتائج المسجلة فقط)

    var summaryStatements: [SummaryStatement] {
        var out: [SummaryStatement] = []
        if demoMode {
            out.append(SummaryStatement(kind: .warning, text: "وضع تجريبي — كل النتائج أدناه وهمية وليست من شبكة سيارة."))
        }
        if !hasScanned {
            out.append(SummaryStatement(kind: .fact, text: "لم يُجرَ أي فحص بعد — شغّل «فحص شامل» من الشاشة الرئيسية."))
            return out
        }
        if let active = interfaces.first(where: { $0.isActive }) {
            out.append(SummaryStatement(kind: .fact, text: "الواجهة النشطة: \(active.name) (\(active.kindLabelAr)) — \(active.ip ?? "بلا IP")."))
        }
        if localNetworkPermission == .denied {
            out.append(SummaryStatement(kind: .warning, text: "إذن الشبكة المحلية مرفوض\(permissionErrorCode.map { " (رمز \($0))" } ?? "") — هذا يمنع اكتشاف الأجهزة والخدمات بصمت. فعّله من إعدادات التطبيق."))
        }
        if hosts.isEmpty {
            out.append(SummaryStatement(kind: .conclusion, text: "لم يرد أي جهاز على الفحص — تأكد أن الآيفون متصل بشبكة الشاشة فعلاً وأن الفحص جرى أثناء بثها."))
        } else {
            out.append(SummaryStatement(kind: .fact, text: "رُصد \(hosts.count) جهازاً يرد على الشبكة: \(hosts.map { $0.ip }.joined(separator: ", "))."))
            if let likely = likelyScreenDevice {
                out.append(SummaryStatement(kind: .fact, text: "جهاز الشاشة المرجح: \(likely.ip)\(likely.hostname.map { " (\($0))" } ?? "") — أول جهاز ردّ على الشبكة."))
            }
        }
        if !gatewayCandidates.isEmpty {
            let confirmed = gatewayCandidates.filter { $0.responded }
            if confirmed.isEmpty {
                out.append(SummaryStatement(kind: .warning, text: "لا مرشح بوابة ردّ على الفحص (\(gatewayCandidates.map { $0.ip }.joined(separator: ", "))) — البوابة تقدير من النطاق فقط."))
            } else {
                out.append(SummaryStatement(kind: .fact, text: "البوابة المؤكدة بردّ مباشر: \(confirmed.map { $0.ip }.joined(separator: ", "))."))
            }
        }
        if openPorts.isEmpty {
            out.append(SummaryStatement(kind: .conclusion, text: "لا توجد خدمات مكشوفة على هذه الشبكة — كل المنافذ المفحوصة مغلقة أو بلا رد. لا يوجد ما يدل على بوابة تشخيص."))
        } else {
            let list = openPorts.map { "\($0.host):\($0.port)" }.joined(separator: ", ")
            out.append(SummaryStatement(kind: .fact, text: "منافذ مفتوحة: \(list)."))
            let mediaOnly = openPorts.allSatisfy { [7000, 7001, 7100, 8000, 8080, 80, 443].contains($0.port) }
                && !bonjour.services.isEmpty
                && bonjour.services.allSatisfy { $0.type.contains("airplay") || $0.type.contains("raop") }
            if mediaOnly {
                out.append(SummaryStatement(kind: .conclusion, text: "ما وُجد هو خدمات وسائط (AirPlay/RAOP) فقط — هذه شبكة وسائط للصوت والصورة، لا بوابة تشخيص لوحدات السيارة."))
            }
            if openPorts.contains(where: { $0.port == 22 || $0.port == 23 }) {
                out.append(SummaryStatement(kind: .warning, text: "وجدنا منفذ تحكم عن بعد مفتوحاً (SSH/Telnet) — نتيجة غير معتادة على شبكة سيارة؛ سُجلت كما وردت وتحتاج تحققاً مستقلاً قبل أي استنتاج."))
            }
            if openPorts.contains(where: { $0.port == 5000 || $0.port == 49152 || $0.port == 49153 }) {
                out.append(SummaryStatement(kind: .fact, text: "وجدنا منافذ خدمات شبكية (5000/49152) — قد تكون خدمات اكتشاف/وسائط؛ راجع لافتاتها في شاشة المنافذ."))
            }
        }
        if bonjour.services.isEmpty && ssdpServices.isEmpty {
            out.append(SummaryStatement(kind: .fact, text: "لم تُكتشف أي خدمة معلنة (لا Bonjour ولا UPnP) على الشبكة."))
        } else {
            if !bonjour.services.isEmpty {
                out.append(SummaryStatement(kind: .fact, text: "خدمات Bonjour المكتشفة: \(bonjour.services.map { "\($0.name) (\($0.type))" }.joined(separator: "، "))."))
            }
            if !ssdpServices.isEmpty {
                out.append(SummaryStatement(kind: .fact, text: "خدمات UPnP/SSDP المكتشفة: \(ssdpServices.map { "\($0.server) — \($0.location)" }.joined(separator: "، "))."))
            }
        }
        if !discoveredServiceTypes.isEmpty {
            out.append(SummaryStatement(kind: .fact, text: "أنواع الخدمات المعلنة على الشبكة (DNS-SD): \(discoveredServiceTypes.joined(separator: ", "))."))
        }
        if !tlsResults.isEmpty {
            out.append(SummaryStatement(kind: .fact, text: "شهادات TLS مقروءة: \(tlsResults.map { "\($0.host):\($0.port) — \($0.subject)" }.joined(separator: "، "))."))
        }
        if !traceHops.isEmpty {
            let reached = traceHops.contains { $0.ip == network.gateway }
            out.append(SummaryStatement(kind: .fact, text: "تتبع المسار إلى البوابة: \(traceHops.count) قفزة\(reached ? " — وصل إلى البوابة" : " — لم يصل إلى البوابة")."))
        }
        if !httpResults.isEmpty {
            let ok = httpResults.filter { $0.statusCode != nil }
            out.append(SummaryStatement(kind: .fact, text: "فحص HTTP: \(ok.count) من \(httpResults.count) طلباً ردّ برمز حالة."))
        }
        if !obstacles.isEmpty {
            let shown = obstacles.prefix(3).map { $0.title }.joined(separator: "؛ ")
            out.append(SummaryStatement(kind: .warning, text: "عقبات مسجلة (\(obstacles.count)): \(shown)\(obstacles.count > 3 ? " وغيرها" : "") — راجع قسم العقبات للسبب والإصلاح."))
        }
        out.append(SummaryStatement(kind: .conclusion, text: "هذا الملخص مبني على نتائج الفحص المسجلة فقط — لا استنتاج خارجها."))
        return out
    }
}
