import Foundation

// MARK: - BonjourScanner
/// اكتشاف خدمات Bonjour (mDNS) على الشبكة المحلية عبر NetServiceBrowser.
/// ملاحظة: البحث يحتاج إذن الشبكة المحلية من iOS (يظهر عند أول استخدام) وأنواع
/// الخدمات مسجلة في Info.plist (NSBonjourServices) — بلا ذلك لا يجد شيئاً.
/// الخدمات تُحلّ (resolve) لمعرفة اسم المضيف والمنفذ؛ ما لم يُحلّ لا يُعرض.

final class BonjourScanner: NSObject, ObservableObject, NetServiceBrowserDelegate, NetServiceDelegate {
    @Published private(set) var services: [BonjourServiceInfo] = []
    @Published private(set) var isSearching = false
    /// v1.1 — أنواع الخدمات المعلنة التي سُردت من _services._dns-sd._udp.
    @Published private(set) var discoveredTypes: [String] = []

    /// تُستدعى عند اكتشاف خدمة محلولة.
    var onFound: ((BonjourServiceInfo) -> Void)?
    /// تُستدعى لأحداث التشغيل (بدء/فشل) لتُسجَّل في السجل.
    var onEvent: ((String, ProbeLogLevel) -> Void)?
    /// v1.1 — تُستدعى عند فشل البحث بخطأ (غالباً رفض إذن الشبكة المحلية)
    /// مع رمز الخطأ كما ورد من iOS.
    var onSearchFailed: ((Int) -> Void)?
    /// v1.1 — تُستدعى عند سرد نوع خدمة جديد من استعلام DNS-SD الكامل.
    var onTypeFound: ((String) -> Void)?

    private var browsers: [NetServiceBrowser] = []
    private var resolving: Set<NetService> = []
    /// v1.1 — متصفح استعلام الأنواع المعلنة (_services._dns-sd._udp).
    private var metaBrowser: NetServiceBrowser?
    private var metaTypes = Set<String>()
    private var isMetaBrowsing = false

    /// يبدأ البحث — يجب أن يُستدعى من الخيط الرئيسي (دورة تشغيل NetServiceBrowser).
    func start(types: [String]) {
        stop()
        services.removeAll()
        isSearching = true
        for type in types {
            let browser = NetServiceBrowser()
            browser.delegate = self
            browser.searchForServices(ofType: type, inDomain: "")
            browsers.append(browser)
        }
        onEvent?("بدأ البحث عن خدمات Bonjour (\(types.count) أنواع)", .info)
    }

    /// v1.1 — سرد كل أنواع الخدمات المعلنة أولاً عبر _services._dns-sd._udp،
    /// ثم البحث عن كل نوع منها. يعيد الأنواع التي سُردت خلال المهلة.
    /// ملاحظة: اسم الخدمة الوارد من هذا الاستعلام هو نوع الخدمة نفسه
    /// (مثل "_http._tcp.") ولا يحتاج حلاً.
    func enumerateServiceTypes(seconds: TimeInterval = 6) async -> [String] {
        metaTypes.removeAll()
        discoveredTypes.removeAll()
        isMetaBrowsing = true
        let browser = NetServiceBrowser()
        browser.delegate = self
        metaBrowser = browser
        browser.searchForServices(ofType: "_services._dns-sd._udp.", inDomain: "local.")
        onEvent?("سرد أنواع الخدمات المعلنة (DNS-SD)…", .info)
        try? await Task.sleep(nanoseconds: UInt64(seconds * 1_000_000_000))
        browser.stop()
        metaBrowser = nil
        isMetaBrowsing = false
        let types = Array(metaTypes).sorted()
        discoveredTypes = types
        return types
    }

    func stop() {
        for browser in browsers {
            browser.stop()
        }
        browsers.removeAll()
        resolving.removeAll()
        metaBrowser?.stop()
        metaBrowser = nil
        isMetaBrowsing = false
        isSearching = false
    }

    /// يفرغ قائمة الخدمات المكتشفة (تُستخدم عند الخروج من التجريبي).
    func clearServices() {
        services.removeAll()
    }

    /// يضيف خدمة إلى القائمة مع منع التكرار (يُستخدم في الوضع التجريبي).
    /// ملاحظة: `services` ذات setter خاص، فلا يصح الإلحاق المباشر من خارج
    /// الصنف — هذا كان خطأ تجميع التشغيل 4 (ProbeRunner.swift:207).
    func addService(_ info: BonjourServiceInfo) {
        if !services.contains(where: { $0.name == info.name && $0.type == info.type }) {
            services.append(info)
        }
    }

    // MARK: NetServiceBrowserDelegate

    func netServiceBrowser(_ browser: NetServiceBrowser, didFind service: NetService, moreComing: Bool) {
        if browser === metaBrowser {
            // استعلام الأنواع: الاسم هو نوع الخدمة نفسه (مثل "_http._tcp.").
            let type = service.name
            if type.hasPrefix("_"), !metaTypes.contains(type) {
                metaTypes.insert(type)
                DispatchQueue.main.async { [weak self] in
                    self?.discoveredTypes = Array(self?.metaTypes ?? []).sorted()
                    self?.onTypeFound?(type)
                }
            }
            return
        }
        service.delegate = self
        resolving.insert(service)
        service.resolve(withTimeout: 5.0)
    }

    func netServiceBrowser(_ browser: NetServiceBrowser, didRemove service: NetService, moreComing: Bool) {
        DispatchQueue.main.async { [weak self] in
            self?.services.removeAll { $0.name == service.name && $0.type == service.type }
        }
    }

    func netServiceBrowser(_ browser: NetServiceBrowser, didNotSearch errorDict: [String: NSNumber]) {
        let code = errorDict[NetService.errorCode]?.intValue ?? -1
        onEvent?("فشل البحث عن خدمات Bonjour (رمز \(code)) — تحقق من إذن الشبكة المحلية", .error)
        // v1.1: أي فشل بحث هنا يُبلَّغ كاحتمال رفض إذن — المنسّق يسجله عقبة.
        onSearchFailed?(code)
    }

    // MARK: NetServiceDelegate

    func netServiceDidResolveAddress(_ sender: NetService) {
        resolving.remove(sender)
        let host = sender.hostName ?? firstIPv4(from: sender.addresses) ?? "—"
        let info = BonjourServiceInfo(name: sender.name, type: sender.type, host: host, port: sender.port, isDemo: false)
        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            if !self.services.contains(where: { $0.name == info.name && $0.type == info.type }) {
                self.services.append(info)
            }
            self.onFound?(info)
        }
    }

    func netService(_ sender: NetService, didNotResolve errorDict: [String: NSNumber]) {
        resolving.remove(sender)
        onEvent?("تعذر حلّ خدمة Bonjour «\(sender.name)» (\(sender.type))", .warning)
    }

    /// أول عنوان IPv4 من بيانات العناوين الخام.
    private func firstIPv4(from addresses: [Data]?) -> String? {
        guard let addresses else { return nil }
        for data in addresses {
            guard data.count >= MemoryLayout<sockaddr_in>.size else { continue }
            let sin = data.withUnsafeBytes { $0.load(as: sockaddr_in.self) }
            if sin.sin_family == UInt8(AF_INET), let cstr = inet_ntoa(sin.sin_addr) {
                return String(cString: cstr)
            }
        }
        return nil
    }
}
