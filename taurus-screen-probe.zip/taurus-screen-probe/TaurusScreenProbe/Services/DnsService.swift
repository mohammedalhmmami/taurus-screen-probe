import Foundation

// MARK: - DnsService
/// بحث DNS العكسي (IP ← اسم مضيف) عبر getnameinfo — قراءة فقط.
/// يعيد nil إن لم يُحلّ الاسم (شائع لأجهزة لا تعلن اسماً).

final class DnsService: Sendable {
    /// يحلّ عنوان IP إلى اسم مضيف إن وجد؛ nil عند الفشل أو انعدام الاسم.
    func reverseLookup(ip: String) async -> String? {
        await withCheckedContinuation { cont in
            DispatchQueue.global(qos: .userInitiated).async {
                cont.resume(returning: Self.reverseLookupSync(ip: ip))
            }
        }
    }

    private static func reverseLookupSync(ip: String) -> String? {
        var addr = sockaddr_in()
        addr.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
        addr.sin_family = sa_family_t(AF_INET)
        addr.sin_addr.s_addr = inet_addr(ip)
        guard addr.sin_addr.s_addr != INADDR_NONE else { return nil }
        var hostBuffer = [CChar](repeating: 0, count: Int(NI_MAXHOST))
        let result = withUnsafePointer(to: &addr) { addrPtr in
            addrPtr.withMemoryRebound(to: sockaddr.self, capacity: 1) { sockPtr in
                getnameinfo(sockPtr, socklen_t(MemoryLayout<sockaddr_in>.size),
                            &hostBuffer, socklen_t(hostBuffer.count),
                            nil, 0, NI_NAMEREQD)
            }
        }
        guard result == 0 else { return nil }
        let name = String(cString: hostBuffer)
        return name.isEmpty ? nil : name
    }
}
