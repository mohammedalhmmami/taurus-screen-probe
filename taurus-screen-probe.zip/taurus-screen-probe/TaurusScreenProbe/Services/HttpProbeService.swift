import Foundation

// MARK: - HttpProbeService
/// فحص HTTP موسّع: GET وHEAD لمسارات شائعة، وOPTIONS لسرد الطرق المسموحة،
/// مع تسجيل رمز الحالة والترويسات وأول 2KB فقط من الجسم (مقتطعاً).
/// قراءة فقط: لا يتبع روابط ولا يرسل بيانات ولا يحاول دخولاً.
/// ملاحظة: HTTP العادي (غير المشفر) يحتاج NSAllowsArbitraryLoads في Info.plist،
/// وهو مضبوط هنا لأن الفحص كله على الشبكة المحلية للسيارة.

struct HttpProbeOutcome {
    let statusCode: Int?
    let headers: [(String, String)]
    let bodyPrefix: String
    /// طرق HTTP المسموحة من رد OPTIONS — nil إن لم تُطلب.
    let allowedMethods: String?
    let error: String?
}

final class HttpProbeService {
    /// GET ‏/‏ — للتوافق مع الاستخدام القديم.
    func probe(host: String, port: Int) async -> HttpProbeOutcome {
        await probe(host: host, port: port, path: "/", method: "GET")
    }

    /// طلب HTTP واحد بمسار وطريقة محددين.
    func probe(host: String, port: Int, path: String, method: String) async -> HttpProbeOutcome {
        guard let url = URL(string: "http://\(host):\(port)\(path)") else {
            return HttpProbeOutcome(statusCode: nil, headers: [], bodyPrefix: "", allowedMethods: nil, error: "عنوان URL غير صالح")
        }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.timeoutInterval = 5
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 5
        config.timeoutIntervalForResource = 8
        let session = URLSession(configuration: config)
        do {
            let (data, response) = try await session.data(for: request)
            let http = response as? HTTPURLResponse
            var headers: [(String, String)] = []
            var allowed: String? = nil
            if let fields = http?.allHeaderFields {
                for (key, value) in fields {
                    headers.append(("\(key)", "\(value)"))
                    if "\(key)".lowercased() == "allow" {
                        allowed = "\(value)"
                    }
                }
                headers.sort { $0.0 < $1.0 }
            }
            // HEAD بلا جسم بطبيعته — لا يُقرأ جسم.
            let body = method == "HEAD" ? "" : String(decoding: data.prefix(2048), as: UTF8.self)
            return HttpProbeOutcome(statusCode: http?.statusCode, headers: headers, bodyPrefix: body, allowedMethods: allowed, error: nil)
        } catch {
            return HttpProbeOutcome(statusCode: nil, headers: [], bodyPrefix: "", allowedMethods: nil, error: error.localizedDescription)
        }
    }
}
