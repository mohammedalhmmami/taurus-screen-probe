import Foundation

// MARK: - HttpProbeService
/// فحص HTTP بسيط: GET ‏/‏ على منفذ مفتوح، وتسجيل رمز الحالة والترويسات
/// وأول 2KB فقط من الجسم (مقتطعاً).
/// ملاحظة: HTTP العادي (غير المشفر) يحتاج NSAllowsArbitraryLoads في Info.plist،
/// وهو مضبوط هنا لأن الفحص كله على الشبكة المحلية للسيارة.

struct HttpProbeOutcome {
    let statusCode: Int?
    let headers: [(String, String)]
    let bodyPrefix: String
    let error: String?
}

final class HttpProbeService {
    func probe(host: String, port: Int) async -> HttpProbeOutcome {
        guard let url = URL(string: "http://\(host):\(port)/") else {
            return HttpProbeOutcome(statusCode: nil, headers: [], bodyPrefix: "", error: "عنوان URL غير صالح")
        }
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 5
        config.timeoutIntervalForResource = 8
        let session = URLSession(configuration: config)
        do {
            let (data, response) = try await session.data(from: url)
            let http = response as? HTTPURLResponse
            var headers: [(String, String)] = []
            if let fields = http?.allHeaderFields {
                for (key, value) in fields {
                    headers.append(("\(key)", "\(value)"))
                }
                headers.sort { $0.0 < $1.0 }
            }
            let body = String(decoding: data.prefix(2048), as: UTF8.self)
            return HttpProbeOutcome(statusCode: http?.statusCode, headers: headers, bodyPrefix: body, error: nil)
        } catch {
            return HttpProbeOutcome(statusCode: nil, headers: [], bodyPrefix: "", error: error.localizedDescription)
        }
    }
}
