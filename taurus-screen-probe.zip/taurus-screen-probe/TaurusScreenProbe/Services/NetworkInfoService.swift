import Foundation
import Network
import SystemConfiguration.CaptiveNetwork

// MARK: - NetworkInfoService
/// قراءة معلومات الشبكة الحالية كما تسمح بها iOS فعلياً.
/// كل ما لا تستطيع iOS كشفه يُعاد nil ويُعرض في الواجهة «غير متاح من iOS» بصراحة —
/// لا تُخترع قيمة ولا تُقدَّر من مصدر آخر.

struct InterfaceAddress {
    let name: String
    let ip: String
    let netmask: String?
}

final class NetworkInfoService {

    // MARK: - واجهة Wi-Fi (en0)

    /// عنوان IP وقناع الشبكة لواجهة en0 (Wi-Fi).
    static func wifiInterface() -> InterfaceAddress? {
        var head: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&head) == 0, let first = head else { return nil }
        defer { freeifaddrs(first) }
        var cursor: UnsafeMutablePointer<ifaddrs>? = first
        while let node = cursor {
            let flags = node.pointee.ifa_flags
            let name = String(cString: node.pointee.ifa_name)
            let isUp = (flags & UInt32(IFF_UP)) != 0
            let isLoopback = (flags & UInt32(IFF_LOOPBACK)) != 0
            if isUp && !isLoopback && name == "en0",
               let addr = node.pointee.ifa_addr,
               addr.pointee.sa_family == UInt8(AF_INET) {
                var sin = sockaddr_in()
                memcpy(&sin, addr, Int(addr.pointee.sa_len))
                guard let cstr = inet_ntoa(sin.sin_addr) else {
                    cursor = node.pointee.ifa_next
                    continue
                }
                let ip = String(cString: cstr)
                var mask: String? = nil
                if let nm = node.pointee.ifa_netmask {
                    var msin = sockaddr_in()
                    memcpy(&msin, nm, Int(nm.pointee.sa_len))
                    if let mstr = inet_ntoa(msin.sin_addr) {
                        mask = String(cString: mstr)
                    }
                }
                return InterfaceAddress(name: name, ip: ip, netmask: mask)
            }
            cursor = node.pointee.ifa_next
        }
        return nil
    }

    // MARK: - البوابة الافتراضية

    /// البوابة من جدول التوجيه عبر sysctl (NET_RT_DUMP) — الطريقة النظامية في BSD.
    /// تعيد nil إن تعذر الوصول إلى الجدول.
    static func systemDefaultGateway() -> String? {
        var mib: [Int32] = [CTL_NET, PF_ROUTE, 0, AF_INET, NET_RT_FLAGS, RTF_GATEWAY]
        var needed = 0
        guard sysctl(&mib, UInt32(mib.count), nil, &needed, nil, 0) == 0, needed > 0 else {
            return nil
        }
        var buffer = [UInt8](repeating: 0, count: needed)
        guard sysctl(&mib, UInt32(mib.count), &buffer, &needed, nil, 0) == 0 else {
            return nil
        }
        var offset = 0
        while offset + MemoryLayout<rt_msghdr>.size <= needed {
            let header = buffer.withUnsafeBytes { $0.load(fromByteOffset: offset, as: rt_msghdr.self) }
            guard header.rtm_msglen > 0 else { break }
            let end = offset + Int(header.rtm_msglen)
            guard end <= needed else { break }
            if (header.rtm_flags & RTF_GATEWAY) != 0 {
                var saOffset = offset + MemoryLayout<rt_msghdr>.size
                var dst: sockaddr_in?
                var gw: sockaddr_in?
                for index in 0..<RTAX_MAX {
                    guard saOffset + MemoryLayout<sockaddr>.size <= end else { break }
                    if (header.rtm_addrs & Int32(1 << index)) != 0 {
                        let saLen = Int(buffer.withUnsafeBytes { $0.load(fromByteOffset: saOffset, as: sockaddr.self).sa_len })
                        let rounded = saLen > 0 ? (1 + ((saLen - 1) | 7)) : 8
                        if index == RTAX_DST || index == RTAX_GATEWAY {
                            let sin = buffer.withUnsafeBytes { $0.load(fromByteOffset: saOffset, as: sockaddr_in.self) }
                            if sin.sin_family == UInt8(AF_INET) {
                                if index == RTAX_DST { dst = sin } else { gw = sin }
                            }
                        }
                        saOffset += rounded
                    }
                }
                if let d = dst, let g = gw, d.sin_addr.s_addr == 0 {
                    guard let cstr = inet_ntoa(g.sin_addr) else { return nil }
                    return String(cString: cstr)
                }
            }
            offset = end
        }
        return nil
    }

    /// البوابة المرجّحة: أول عنوان في النطاق (x.x.x.1) — تُعرض كمرجّحة لا كمؤكدة.
    static func heuristicGateway(for ip: String) -> String? {
        let parts = ip.split(separator: ".").compactMap { Int($0) }
        guard parts.count == 4 else { return nil }
        return "\(parts[0]).\(parts[1]).\(parts[2]).1"
    }

    // MARK: - DNS

    /// خوادم DNS من /etc/resolv.conf (إن سمح النظام بقراءته).
    static func dnsServers() -> [String] {
        guard let text = try? String(contentsOfFile: "/etc/resolv.conf", encoding: .utf8) else {
            return []
        }
        var servers: [String] = []
        for line in text.split(separator: "\n") {
            let parts = line.split(separator: " ")
            if parts.count >= 2 && parts[0] == "nameserver" {
                servers.append(String(parts[1]))
            }
        }
        return servers
    }

    // MARK: - SSID

    /// اسم الشبكة الحالية عبر CaptiveNetwork.
    /// ملاحظة صريحة: بدءاً من iOS 14 تعيد هذه الدالة nil بلا صلاحية
    /// com.apple.developer.networking.wifi-info — عندها يُعرض «غير متاح من iOS».
    static func currentSSID() -> String? {
        guard let interfaces = CNCopySupportedInterfaces() as? [String] else { return nil }
        for name in interfaces {
            if let info = CNCopyCurrentNetworkInfo(name as CFString) as? [String: Any],
               let ssid = info[kCNNetworkInfoKeySSID as String] as? String {
                return ssid
            }
        }
        return nil
    }

    // MARK: - قراءة كاملة

    /// يجمع كل ما تستطيع iOS كشفه في NetworkInfo واحدة.
    static func readCurrent(isWiFi: Bool) -> NetworkInfo {
        let iface = wifiInterface()
        let ssid = currentSSID()
        var gateway: String? = systemDefaultGateway()
        var source: GatewaySource = .system
        if gateway == nil, let ip = iface?.ip {
            gateway = heuristicGateway(for: ip)
            source = gateway == nil ? .unavailable : .heuristic
        }
        if gateway == nil { source = .unavailable }
        return NetworkInfo(
            ssid: ssid,
            ssidAvailable: ssid != nil,
            localIP: iface?.ip,
            netmask: iface?.netmask,
            interfaceName: iface?.name,
            gateway: gateway,
            gatewaySource: source,
            dnsServers: dnsServers(),
            isWiFi: isWiFi,
            isDemo: false
        )
    }
}

// MARK: - PathWatcher
/// مراقب حالة الشبكة عبر NWPathMonitor — يعرف فقط إن كان الاتصال Wi-Fi أم لا.
final class PathWatcher: ObservableObject {
    @Published var isWiFi = false
    @Published var isSatisfied = false

    private let monitor = NWPathMonitor()

    init() {
        monitor.pathUpdateHandler = { [weak self] path in
            DispatchQueue.main.async {
                self?.isSatisfied = path.status == .satisfied
                self?.isWiFi = path.status == .satisfied && path.usesInterfaceType(.wifi)
            }
        }
        monitor.start(queue: .global())
    }
}
