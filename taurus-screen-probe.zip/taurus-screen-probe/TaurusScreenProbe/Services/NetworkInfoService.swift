import Foundation
import Network
import SystemConfiguration.CaptiveNetwork

// MARK: - NetworkInfoService
/// قراءة معلومات الشبكة الحالية كما تسمح بها iOS فعلياً.
/// كل ما لا تستطيع iOS كشفه يُعاد nil ويُعرض في الواجهة «غير متاح من iOS» بصراحة —
/// لا تُخترع قيمة ولا تُقدَّر من مصدر آخر.

struct InterfaceAddress {
    let name: String
    let ip: String
    let netmask: String?
}

final class NetworkInfoService {

    // MARK: - واجهة Wi-Fi (en0)

    /// عنوان IP وقناع الشبكة لواجهة en0 (Wi-Fi).
    static func wifiInterface() -> InterfaceAddress? {
        var head: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&head) == 0, let first = head else { return nil }
        defer { freeifaddrs(first) }
        var cursor: UnsafeMutablePointer<ifaddrs>? = first
        while let node = cursor {
            let flags = node.pointee.ifa_flags
            let name = String(cString: node.pointee.ifa_name)
            let isUp = (flags & UInt32(IFF_UP)) != 0
            let isLoopback = (flags & UInt32(IFF_LOOPBACK)) != 0
            if isUp && !isLoopback && name == "en0",
               let addr = node.pointee.ifa_addr,
               addr.pointee.sa_family == UInt8(AF_INET) {
                var sin = sockaddr_in()
                memcpy(&sin, addr, Int(addr.pointee.sa_len))
                guard let cstr = inet_ntoa(sin.sin_addr) else {
                    cursor = node.pointee.ifa_next
                    continue
                }
                let ip = String(cString: cstr)
                var mask: String? = nil
                if let nm = node.pointee.ifa_netmask {
                    var msin = sockaddr_in()
                    memcpy(&msin, nm, Int(nm.pointee.sa_len))
                    if let mstr = inet_ntoa(msin.sin_addr) {
                        mask = String(cString: mstr)
                    }
                }
                return InterfaceAddress(name: name, ip: ip, netmask: mask)
            }
            cursor = node.pointee.ifa_next
        }
        return nil
    }

    // MARK: - البوابة الافتراضية

    // ملاحظة: قراءة جدول التوجيه عبر sysctl (NET_RT_DUMP) غير ممكنة في Swift
    // على iOS — رموز <net/route.h> مثل RTF_GATEWAY وrt_msghdr وRTAX_MAX غير
    // مستوردة في وحدة Darwin، فأي كود يستخدمها يفشل في التجميع (خطأ بناء run 1).
    // البديل: البوابة المرجّحة من النطاق المحلي أدناه، ومسح الاكتشاف يؤكد
    // العنوان الفعلي الذي يرد على الشبكة. لا تُعِد إضافة كود sysctl هنا.

    /// البوابة المرجّحة: أول عنوان في النطاق (x.x.x.1) — تُعرض كمرجّحة لا كمؤكدة.
    static func heuristicGateway(for ip: String) -> String? {
        let parts = ip.split(separator: ".").compactMap { Int($0) }
        guard parts.count == 4 else { return nil }
        return "\(parts[0]).\(parts[1]).\(parts[2]).1"
    }

    // MARK: - DNS

    /// خوادم DNS من /etc/resolv.conf (إن سمح النظام بقراءته).
    static func dnsServers() -> [String] {
        guard let text = try? String(contentsOfFile: "/etc/resolv.conf", encoding: .utf8) else {
            return []
        }
        var servers: [String] = []
        for line in text.split(separator: "\n") {
            let parts = line.split(separator: " ")
            if parts.count >= 2 && parts[0] == "nameserver" {
                servers.append(String(parts[1]))
            }
        }
        return servers
    }

    // MARK: - SSID

    /// اسم الشبكة الحالية عبر CaptiveNetwork.
    /// ملاحظة صريحة: بدءاً من iOS 14 تعيد هذه الدالة nil بلا صلاحية
    /// com.apple.developer.networking.wifi-info — عندها يُعرض «غير متاح من iOS».
    static func currentSSID() -> String? {
        guard let interfaces = CNCopySupportedInterfaces() as? [String] else { return nil }
        for name in interfaces {
            if let info = CNCopyCurrentNetworkInfo(name as CFString) as? [String: Any],
               let ssid = info[kCNNetworkInfoKeySSID as String] as? String {
                return ssid
            }
        }
        return nil
    }

    // MARK: - قراءة كاملة

    /// يجمع كل ما تستطيع iOS كشفه في NetworkInfo واحدة.
    static func readCurrent(isWiFi: Bool) -> NetworkInfo {
        let iface = wifiInterface()
        let ssid = currentSSID()
        // البوابة تُقدَّر من النطاق المحلي (x.x.x.1) وتُعرض كمرجّحة —
        // انظر الملاحظة أعلاه عن sysctl. مسح الاكتشاف يؤكد العنوان الفعلي.
        var gateway: String? = nil
        var source: GatewaySource = .unavailable
        if let ip = iface?.ip {
            gateway = heuristicGateway(for: ip)
            source = gateway == nil ? .unavailable : .heuristic
        }
        return NetworkInfo(
            ssid: ssid,
            ssidAvailable: ssid != nil,
            localIP: iface?.ip,
            netmask: iface?.netmask,
            interfaceName: iface?.name,
            gateway: gateway,
            gatewaySource: source,
            dnsServers: dnsServers(),
            isWiFi: isWiFi,
            isDemo: false
        )
    }
}

// MARK: - PathWatcher
/// مراقب حالة الشبكة عبر NWPathMonitor — يعرف فقط إن كان الاتصال Wi-Fi أم لا.
final class PathWatcher: ObservableObject {
    @Published var isWiFi = false
    @Published var isSatisfied = false

    private let monitor = NWPathMonitor()

    init() {
        monitor.pathUpdateHandler = { [weak self] path in
            DispatchQueue.main.async {
                self?.isSatisfied = path.status == .satisfied
                self?.isWiFi = path.status == .satisfied && path.usesInterfaceType(.wifi)
            }
        }
        monitor.start(queue: .global())
    }
}
