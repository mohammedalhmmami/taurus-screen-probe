import Foundation
import Network
import SystemConfiguration.CaptiveNetwork

// MARK: - NetworkInfoService
/// قراءة معلومات الشبكة الحالية كما تسمح بها iOS فعلياً.
/// v1.1: سرد كل الواجهات (لا افتراض en0 وحدها)، واختيار الواجهة النشطة
/// المتصلة فعلاً، وقراءة BSSID، وترشيح البوابة من أكثر من عنوان.
/// كل ما لا تستطيع iOS كشفه يُعاد nil ويُعرض في الواجهة «غير متاح من iOS»
/// بصراحة — لا تُخترع قيمة ولا تُقدَّر من مصدر آخر.

struct InterfaceAddress {
    let name: String
    let ip: String
    let netmask: String?
}

final class NetworkInfoService {

    // MARK: - كل الواجهات

    /// كل واجهات IPv4 الظاهرة في getifaddrs (up، بلا loopback)،
    /// مع عنوان IP وقناع الشبكة لكل واحدة.
    static func allInterfaces() -> [InterfaceInfo] {
        var head: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&head) == 0, let first = head else { return [] }
        defer { freeifaddrs(first) }
        var out: [InterfaceInfo] = []
        var seen = Set<String>()
        var cursor: UnsafeMutablePointer<ifaddrs>? = first
        while let node = cursor {
            let flags = node.pointee.ifa_flags
            let name = String(cString: node.pointee.ifa_name)
            let isUp = (flags & UInt32(IFF_UP)) != 0
            let isLoopback = (flags & UInt32(IFF_LOOPBACK)) != 0
            if isUp && !isLoopback, !seen.contains(name),
               let addr = node.pointee.ifa_addr,
               addr.pointee.sa_family == UInt8(AF_INET) {
                seen.insert(name)
                var sin = sockaddr_in()
                memcpy(&sin, addr, Int(addr.pointee.sa_len))
                let ip = inet_ntoa(sin.sin_addr).map { String(cString: $0) }
                var mask: String? = nil
                if let nm = node.pointee.ifa_netmask {
                    var msin = sockaddr_in()
                    memcpy(&msin, nm, Int(nm.pointee.sa_len))
                    mask = inet_ntoa(msin.sin_addr).map { String(cString: $0) }
                }
                out.append(InterfaceInfo(name: name, ip: ip, netmask: mask, isUp: isUp, isActive: false))
            }
            cursor = node.pointee.ifa_next
        }
        // الواجهة النشطة: en0 أولاً، وإلا أول واجهة بعنوان IP.
        let activeName: String?
        if out.contains(where: { $0.name == "en0" && $0.ip != nil }) {
            activeName = "en0"
        } else {
            activeName = out.first(where: { $0.ip != nil })?.name
        }
        return out.map { InterfaceInfo(name: $0.name, ip: $0.ip, netmask: $0.netmask, isUp: $0.isUp, isActive: $0.name == activeName) }
    }

    /// واجهة Wi-Fi (en0) — للتوافق مع الكود القديم.
    static func wifiInterface() -> InterfaceAddress? {
        guard let iface = allInterfaces().first(where: { $0.name == "en0" }), let ip = iface.ip else {
            return nil
        }
        return InterfaceAddress(name: "en0", ip: ip, netmask: iface.netmask)
    }

    /// الواجهة النشطة المتصلة فعلاً (en0 إن وجدت، وإلا أول واجهة بعنوان IP).
    static func activeInterface() -> InterfaceInfo? {
        allInterfaces().first(where: { $0.isActive })
    }

    // MARK: - البوابة

    // ملاحظة: قراءة جدول التوجيه عبر sysctl (NET_RT_DUMP) غير ممكنة في Swift
    // على iOS — رموز <net/route.h> مثل RTF_GATEWAY وrt_msghdr وRTAX_MAX غير
    // مستوردة في وحدة Darwin، فأي كود يستخدمها يفشل في التجميع (خطأ بناء run 1).
    // البديل: مرشحون من النطاق (.1 و.254) يُفحص كل منهم بردّ مباشر،
    // ومسح الاكتشاف يؤكد العنوان الفعلي الذي يرد. لا تُعِد إضافة كود sysctl هنا.

    /// مرشحو البوابة من النطاق المحلي: x.x.x.1 وx.x.x.254 — بلا ردّ مؤكد بعد.
    static func gatewayCandidates(for ip: String) -> [GatewayCandidate] {
        let parts = ip.split(separator: ".").compactMap { Int($0) }
        guard parts.count == 4 else { return [] }
        let base = "\(parts[0]).\(parts[1]).\(parts[2])"
        return [
            GatewayCandidate(ip: "\(base).1", source: "نطاق .1", responded: false, rttMs: nil, isDemo: false),
            GatewayCandidate(ip: "\(base).254", source: "نطاق .254", responded: false, rttMs: nil, isDemo: false)
        ]
    }

    /// البوابة المرجّحة: أول عنوان في النطاق (x.x.x.1) — تُعرض كمرجّحة لا كمؤكدة.
    static func heuristicGateway(for ip: String) -> String? {
        let parts = ip.split(separator: ".").compactMap { Int($0) }
        guard parts.count == 4 else { return nil }
        return "\(parts[0]).\(parts[1]).\(parts[2]).1"
    }

    // MARK: - DNS

    /// خوادم DNS من /etc/resolv.conf (إن سمح النظام بقراءته).
    static func dnsServers() -> [String] {
        guard let text = try? String(contentsOfFile: "/etc/resolv.conf", encoding: .utf8) else {
            return []
        }
        var servers: [String] = []
        for line in text.split(separator: "\n") {
            let parts = line.split(separator: " ")
            if parts.count >= 2 && parts[0] == "nameserver" {
                servers.append(String(parts[1]))
            }
        }
        return servers
    }

    // MARK: - SSID وBSSID

    /// اسم الشبكة الحالية وعنوان MAC لنقطة الوصول عبر CaptiveNetwork.
    /// ملاحظة صريحة: بدءاً من iOS 14 تعيد هذه الدالة nil بلا صلاحية
    /// com.apple.developer.networking.wifi-info — عندها يُعرض «غير متاح من iOS».
    static func currentSSID() -> String? {
        currentNetworkInfo()[kCNNetworkInfoKeySSID as String] as? String
    }

    /// عنوان MAC لنقطة الوصول (BSSID) — بنفس قيد الصلاحية كـ SSID.
    static func currentBSSID() -> String? {
        currentNetworkInfo()[kCNNetworkInfoKeyBSSID as String] as? String
    }

    private static func currentNetworkInfo() -> [String: Any] {
        guard let interfaces = CNCopySupportedInterfaces() as? [String] else { return [:] }
        for name in interfaces {
            if let info = CNCopyCurrentNetworkInfo(name as CFString) as? [String: Any] {
                return info
            }
        }
        return [:]
    }

    // MARK: - قراءة كاملة

    /// يجمع كل ما تستطيع iOS كشفه في NetworkInfo واحدة.
    static func readCurrent(isWiFi: Bool) -> NetworkInfo {
        let interfaces = allInterfaces()
        let active = interfaces.first(where: { $0.isActive })
        let ssid = currentSSID()
        let bssid = currentBSSID()
        let candidates = active?.ip.map { gatewayCandidates(for: $0) } ?? []
        // البوابة الأولية تقدير من النطاق (.1) وتُعرض كمرجّحة حتى يردّ
        // أحد المرشحين بردّ مباشر في resolveGateway.
        var gateway: String? = nil
        var source: GatewaySource = .unavailable
        if let ip = active?.ip {
            gateway = heuristicGateway(for: ip)
            source = gateway == nil ? .unavailable : .heuristic
        }
        return NetworkInfo(
            ssid: ssid,
            ssidAvailable: ssid != nil,
            bssid: bssid,
            localIP: active?.ip,
            netmask: active?.netmask,
            interfaceName: active?.name,
            interfaces: interfaces,
            gateway: gateway,
            gatewaySource: source,
            gatewayCandidates: candidates,
            dnsServers: dnsServers(),
            isWiFi: isWiFi,
            isDemo: false
        )
    }
}

// MARK: - PathWatcher
/// مراقب حالة الشبكة عبر NWPathMonitor — يعرف فقط إن كان الاتصال Wi-Fi أم لا.
final class PathWatcher: ObservableObject {
    @Published var isWiFi = false
    @Published var isSatisfied = false

    private let monitor = NWPathMonitor()

    init() {
        monitor.pathUpdateHandler = { [weak self] path in
            DispatchQueue.main.async {
                self?.isSatisfied = path.status == .satisfied
                self?.isWiFi = path.status == .satisfied && path.usesInterfaceType(.wifi)
            }
        }
        monitor.start(queue: .global())
    }
}
