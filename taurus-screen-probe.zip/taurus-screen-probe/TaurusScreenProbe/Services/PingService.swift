import Foundation

// MARK: - PingService
/// فحص ICMP echo (ping) عبر مقبس datagram — نفس طريقة عينة SimplePing من Apple.
/// SOCK_DGRAM مع IPPROTO_ICMP لا يحتاج صلاحيات الجذر على iOS.
/// إن تعذّر إنشاء المقبس (مثلاً في المحاكي) تعيد .unavailable بصراحة،
/// وعندها يستخدم المنسّق فحص TCP:80 كبديل للاكتشاف ويُسجَّل ذلك.

enum PingOutcome: Sendable {
    case replied(rttMs: Double)
    case noReply
    case unavailable(reason: String)
}

/// الخدمة Sendable (حالتها ثابتة بعد الإنشاء) فالتقاطها في إغلاقات @Sendable آمن.
final class PingService: Sendable {
    private let timeout: TimeInterval

    init(timeout: TimeInterval = 1.0) {
        self.timeout = timeout
    }

    func ping(host: String) async -> PingOutcome {
        await withCheckedContinuation { cont in
            DispatchQueue.global(qos: .userInitiated).async {
                cont.resume(returning: self.pingSync(host: host))
            }
        }
    }

    private func pingSync(host: String) -> PingOutcome {
        let fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_ICMP)
        guard fd >= 0 else {
            return .unavailable(reason: "تعذر إنشاء مقبس ICMP (socket فشل)")
        }
        defer { close(fd) }
        var tv = timeval(tv_sec: Int(timeout), tv_usec: 0)
        setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, socklen_t(MemoryLayout<timeval>.size))

        let identifier = UInt16.random(in: 1...UInt16.max)
        let sequence: UInt16 = 1
        var packet = Data()
        packet.append(8) // نوع ICMP: echo request
        packet.append(0) // الكود
        packet.append(contentsOf: [0, 0]) // التشيكسم (يُحسب بعدها)
        packet.append(contentsOf: withUnsafeBytes(of: identifier.bigEndian) { Array($0) })
        packet.append(contentsOf: withUnsafeBytes(of: sequence.bigEndian) { Array($0) })
        packet.append(contentsOf: "TaurusProbe".utf8)
        let sum = internetChecksum(packet)
        packet[2] = UInt8(sum >> 8)
        packet[3] = UInt8(sum & 0xff)

        var addr = sockaddr_in()
        addr.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
        addr.sin_family = sa_family_t(AF_INET)
        addr.sin_port = 0
        addr.sin_addr.s_addr = inet_addr(host)
        guard addr.sin_addr.s_addr != INADDR_NONE else { return .noReply }

        let sent = packet.withUnsafeBytes { ptr in
            withUnsafePointer(to: &addr) { addrPtr in
                addrPtr.withMemoryRebound(to: sockaddr.self, capacity: 1) { sockPtr in
                    sendto(fd, ptr.baseAddress, packet.count, 0, sockPtr, socklen_t(MemoryLayout<sockaddr_in>.size))
                }
            }
        }
        guard sent == packet.count else { return .noReply }

        var buffer = [UInt8](repeating: 0, count: 1024)
        var from = sockaddr_in()
        var fromLen = socklen_t(MemoryLayout<sockaddr_in>.size)
        let start = Date()
        let received = withUnsafeMutablePointer(to: &from) { fromPtr in
            fromPtr.withMemoryRebound(to: sockaddr.self, capacity: 1) { sockPtr in
                recvfrom(fd, &buffer, buffer.count, 0, sockPtr, &fromLen)
            }
        }
        guard received > 0 else { return .noReply }
        // الرد يحمل ترويسة IP أولاً: طولها من النبل السفلي للبايت الأول × 4.
        let ihl = Int(buffer[0] & 0x0f) * 4
        guard received >= ihl + 8 else { return .noReply }
        let icmpType = buffer[ihl]
        let icmpId = UInt16(buffer[ihl + 4]) << 8 | UInt16(buffer[ihl + 5])
        guard icmpType == 0, icmpId == identifier else { return .noReply }
        return .replied(rttMs: Date().timeIntervalSince(start) * 1000)
    }

    /// تشيكسم الإنترنت القياسي (مكمل الواحد لمجموع الكلمات 16 بت).
    private func internetChecksum(_ data: Data) -> UInt16 {
        let bytes = [UInt8](data)
        var sum: UInt32 = 0
        var i = 0
        while i + 1 < bytes.count {
            sum += UInt32(bytes[i]) << 8 | UInt32(bytes[i + 1])
            i += 2
        }
        if i < bytes.count {
            sum += UInt32(bytes[i]) << 8
        }
        while (sum >> 16) != 0 {
            sum = (sum & 0xffff) + (sum >> 16)
        }
        return ~UInt16(sum & 0xffff)
    }
}
