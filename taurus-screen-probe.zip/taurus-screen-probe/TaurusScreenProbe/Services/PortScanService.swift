import Foundation

// MARK: - PortScanService
/// فحص منافذ TCP عبر مقبس BSD مع مهلة عبر poll — بلا NWConnection وبلا إغلاقات
/// ‏@Sendable‏ (تجنباً لخطأ self الضمني الذي ظهر في مشروع التطبيق الحالي).
/// بعد الاتصال الناجح يُقرأ أي رد فوري (لافتة الخدمة)، وللمنافذ المشهورة
/// بـ HTTP يُرسل طلب GET بسيط أولاً ثم يُقرأ الرد.

struct PortCheck: Sendable {
    let port: Int
    let state: PortState
    let banner: String?
}

/// الخدمة Sendable (حالتها ثابتة بعد الإنشاء) فالتقاطها في إغلاقات @Sendable آمن.
final class PortScanService: Sendable {
    private let connectTimeout: TimeInterval
    private let bannerTimeout: TimeInterval

    /// المنافذ التي يُرسل لها طلب HTTP بعد الاتصال.
    private let httpPorts: Set<Int> = [80, 8080, 8000, 8888, 7000, 5000, 8443]

    init(connectTimeout: TimeInterval = 1.5, bannerTimeout: TimeInterval = 2.0) {
        self.connectTimeout = connectTimeout
        self.bannerTimeout = bannerTimeout
    }

    func check(host: String, port: Int) async -> PortCheck {
        await withCheckedContinuation { cont in
            DispatchQueue.global(qos: .userInitiated).async {
                cont.resume(returning: self.checkSync(host: host, port: port))
            }
        }
    }

    private func checkSync(host: String, port: Int) -> PortCheck {
        let fd = socket(AF_INET, SOCK_STREAM, 0)
        guard fd >= 0 else {
            return PortCheck(port: port, state: .timeout, banner: nil)
        }
        defer { close(fd) }

        var addr = sockaddr_in()
        addr.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
        addr.sin_family = sa_family_t(AF_INET)
        addr.sin_port = in_port_t(UInt16(port)).bigEndian
        addr.sin_addr.s_addr = inet_addr(host)
        guard addr.sin_addr.s_addr != INADDR_NONE else {
            return PortCheck(port: port, state: .closed, banner: nil)
        }

        // اتصال غير حاجب + انتظار عبر poll حتى المهلة.
        let flags = fcntl(fd, F_GETFL, 0)
        _ = fcntl(fd, F_SETFL, flags | O_NONBLOCK)
        let result = withUnsafePointer(to: &addr) { addrPtr in
            addrPtr.withMemoryRebound(to: sockaddr.self, capacity: 1) { sockPtr in
                connect(fd, sockPtr, socklen_t(MemoryLayout<sockaddr_in>.size))
            }
        }
        if result != 0 && errno != EINPROGRESS {
            return PortCheck(port: port, state: .closed, banner: nil)
        }
        if result != 0 {
            var pfd = pollfd(fd: fd, events: Int16(POLLOUT), revents: 0)
            let ready = poll(&pfd, 1, Int32(connectTimeout * 1000))
            if ready <= 0 {
                return PortCheck(port: port, state: .timeout, banner: nil)
            }
            if (pfd.revents & Int16(POLLERR)) != 0 || (pfd.revents & Int16(POLLHUP)) != 0 {
                return PortCheck(port: port, state: .closed, banner: nil)
            }
            var err: Int32 = 0
            var errLen = socklen_t(MemoryLayout<Int32>.size)
            getsockopt(fd, SOL_SOCKET, SO_ERROR, &err, &errLen)
            if err != 0 {
                return PortCheck(port: port, state: .closed, banner: nil)
            }
        }

        // متصل — إعادة الحجب وقراءة اللافتة بمهلة قصيرة.
        _ = fcntl(fd, F_SETFL, flags)
        var tv = timeval(tv_sec: Int(bannerTimeout), tv_usec: 0)
        setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, socklen_t(MemoryLayout<timeval>.size))
        if httpPorts.contains(port) {
            let request = "GET / HTTP/1.0\r\nHost: \(host)\r\nConnection: close\r\n\r\n"
            _ = request.withCString { send(fd, $0, strlen($0), 0) }
        }
        var buffer = [UInt8](repeating: 0, count: 1024)
        let count = recv(fd, &buffer, buffer.count, 0)
        var banner: String? = nil
        if count > 0 {
            let text = String(decoding: buffer[..<count], as: UTF8.self)
            banner = String(text.prefix(512))
        }
        return PortCheck(port: port, state: .open, banner: banner)
    }
}
