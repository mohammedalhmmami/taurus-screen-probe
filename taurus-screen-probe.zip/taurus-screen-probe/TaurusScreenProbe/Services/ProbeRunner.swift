import Foundation

// MARK: - ProbeRunner
/// منسّق الفحص — يشغّل الأدوات بالترتيب ويكتب كل خطوة ونتيجتها الخام في السجل.
/// قراءة فقط بالكامل: فحص شبكة + قراءة لافتات، بلا أي محاولة دخول أو كتابة.

@MainActor
final class ProbeRunner {
    private let state: ProbeState

    init(state: ProbeState) {
        self.state = state
    }

    // MARK: - الشبكة الحالية

    func refreshNetwork() {
        if state.demoMode {
            state.network = NetworkInfo(
                ssid: "SYNC-4-DEMO", ssidAvailable: true,
                localIP: "192.168.1.50", netmask: "255.255.255.0", interfaceName: "en0",
                gateway: "192.168.1.1", gatewaySource: .system,
                dnsServers: ["192.168.1.1"], isWiFi: true, isDemo: true)
            state.log.add(.info, category: "الشبكة", message: "وضع تجريبي: شبكة وهمية 192.168.1.0/24")
            return
        }
        let info = NetworkInfoService.readCurrent(isWiFi: state.pathWatcher.isWiFi)
        state.network = info
        if let ip = info.localIP {
            state.log.add(.success, category: "الشبكة", message: "عنوان الآيفون المحلي: \(ip)", detail: "القناع: \(info.netmask ?? "—") — البوابة: \(info.gateway ?? "—") (\(info.gatewaySource.labelAr))")
        } else {
            state.log.add(.warning, category: "الشبكة", message: "لم تُقرأ واجهة Wi-Fi — هل الآيفون متصل بشبكة؟")
        }
        if info.ssidAvailable, let ssid = info.ssid {
            state.log.add(.info, category: "الشبكة", message: "اسم الشبكة (SSID): \(ssid)")
        } else {
            state.log.add(.warning, category: "الشبكة", message: "اسم الشبكة غير متاح من iOS (يحتاج صلاحية Wi-Fi) — يُعرض «غير متاح» ولا يُقدَّر")
        }
        if info.dnsServers.isEmpty {
            state.log.add(.info, category: "الشبكة", message: "خوادم DNS غير مقروءة من النظام")
        } else {
            state.log.add(.info, category: "الشبكة", message: "خوادم DNS: \(info.dnsServers.joined(separator: ", "))")
        }
    }

    // MARK: - اكتشاف الأجهزة

    /// عناوين النطاق المحلي من IP + القناع (بحد أقصى 256 عنواناً).
    private func subnetHosts() -> [String]? {
        guard let ip = state.network.localIP, let mask = state.network.netmask else { return nil }
        let ipParts = ip.split(separator: ".").compactMap { UInt32($0) }
        let maskParts = mask.split(separator: ".").compactMap { UInt32($0) }
        guard ipParts.count == 4, maskParts.count == 4 else { return nil }
        func toInt(_ p: [UInt32]) -> UInt32 { (p[0] << 24) | (p[1] << 16) | (p[2] << 8) | p[3] }
        let ipNum = toInt(ipParts)
        let maskNum = toInt(maskParts)
        let networkNum = ipNum & maskNum
        let broadcastNum = networkNum | ~maskNum
        var hosts: [String] = []
        var n = networkNum + 1
        while n < broadcastNum && hosts.count < 256 {
            if n != ipNum {
                hosts.append("\((n >> 24) & 0xff).\((n >> 16) & 0xff).\((n >> 8) & 0xff).\(n & 0xff)")
            }
            n += 1
        }
        return hosts
    }

    func runDiscovery() async {
        guard !state.isScanning else { return }
        if state.demoMode {
            state.isScanning = true
            state.hosts = [
                DiscoveredHost(ip: "192.168.1.1", rttMs: 2.3, method: "ICMP ping", isGateway: true, isDemo: true),
                DiscoveredHost(ip: "192.168.1.10", rttMs: 4.1, method: "ICMP ping", isGateway: false, isDemo: true)
            ]
            state.log.add(.success, category: "اكتشاف", message: "تجريبي: جهازان يردان — 192.168.1.1 (البوابة) و192.168.1.10 (APIM وهمي)")
            state.hasScanned = true
            state.isScanning = false
            return
        }
        guard let targets = subnetHosts(), !targets.isEmpty else {
            state.log.add(.error, category: "اكتشاف", message: "تعذر حساب نطاق الشبكة — اقرأ الشبكة الحالية أولاً")
            return
        }
        state.isScanning = true
        state.scanStatus = "جارٍ مسح \(targets.count) عنواناً…"
        state.log.add(.info, category: "اكتشاف", message: "بدء مسح \(targets.count) عنواناً (ICMP ping، مهلة 1 ثانية)")
        state.hosts.removeAll()
        let gatewayIP = state.network.gateway
        // التقاط الخدمة محلياً: إغلاقات addTask ‏@Sendable‏ فلا يجوز فيها
        // الإشارة الضمنية إلى self (خطأ تجميع ظهر في مشروع التطبيق الحالي).
        let pingService = state.ping
        var pingFailed = false
        var found: [DiscoveredHost] = []
        // دفعات متوازية من 32 عنواناً.
        for chunk in targets.chunked(into: 32) {
            let results = await withTaskGroup(of: (String, PingOutcome).self) { group in
                for ip in chunk {
                    group.addTask { (ip, await pingService.ping(host: ip)) }
                }
                var collected: [(String, PingOutcome)] = []
                for await item in group { collected.append(item) }
                return collected
            }
            for (ip, outcome) in results {
                switch outcome {
                case .replied(let rtt):
                    let host = DiscoveredHost(ip: ip, rttMs: rtt, method: "ICMP ping", isGateway: ip == gatewayIP, isDemo: false)
                    found.append(host)
                    state.log.add(.success, category: "اكتشاف", message: "ردّ \(ip) — \(String(format: "%.1f", rtt))ms", detail: "ICMP ping")
                case .noReply:
                    break
                case .unavailable(let reason):
                    if !pingFailed {
                        pingFailed = true
                        state.log.add(.error, category: "اكتشاف", message: "تعذر ICMP ping: \(reason) — التبديل إلى فحص TCP:80 كبديل للاكتشاف", detail: "يُسجَّل البديل في كل نتيجة")
                    }
                    // بديل: اتصال TCP بالمنفذ 80 كدليل وجود.
                    let check = await state.portScan.check(host: ip, port: 80)
                    if check.state == .open {
                        let host = DiscoveredHost(ip: ip, rttMs: nil, method: "TCP:80", isGateway: ip == gatewayIP, isDemo: false)
                        found.append(host)
                        state.log.add(.success, category: "اكتشاف", message: "ردّ \(ip) عبر TCP:80 (بديل ICMP)", detail: "منفذ 80 مفتوح")
                    }
                }
            }
            state.hosts = found.sorted { $0.ip < $1.ip }
            state.scanStatus = "وُجد \(found.count) حتى الآن…"
        }
        state.log.add(.info, category: "اكتشاف", message: "انتهى المسح: \(found.count) جهازاً يرد من \(targets.count) عنواناً")
        state.hasScanned = true
        state.isScanning = false
        state.scanStatus = ""
    }

    // MARK: - فحص المنافذ

    func runPortScan() async {
        guard !state.isScanning else { return }
        if state.demoMode {
            state.isScanning = true
            state.portResults = [
                PortResult(host: "192.168.1.1", port: 80, state: .open, banner: "HTTP/1.1 200 OK\r\nServer: DemoAirPlay/1.0 (رد وهمي موسوم)", isDemo: true),
                PortResult(host: "192.168.1.1", port: 443, state: .closed, banner: nil, isDemo: true),
                PortResult(host: "192.168.1.1", port: 53, state: .closed, banner: nil, isDemo: true),
                PortResult(host: "192.168.1.10", port: 7000, state: .open, banner: "AirPlay — تجريبي", isDemo: true),
                PortResult(host: "192.168.1.10", port: 7001, state: .open, banner: "RAOP — تجريبي", isDemo: true)
            ]
            state.log.add(.success, category: "المنافذ", message: "تجريبي: 3 منافذ مفتوحة (80 على البوابة، 7000/7001 على 192.168.1.10)")
            state.hasScanned = true
            state.isScanning = false
            return
        }
        var targets = state.discoveredIPs
        if let gw = state.network.gateway, !targets.contains(gw) {
            targets.insert(gw, at: 0)
        }
        guard !targets.isEmpty else {
            state.log.add(.error, category: "المنافذ", message: "لا أهداف لفحص المنافذ — شغّل اكتشاف الأجهزة أولاً")
            return
        }
        state.isScanning = true
        state.scanStatus = "جارٍ فحص المنافذ…"
        state.log.add(.info, category: "المنافذ", message: "فحص \(state.commonPorts.count) منفذاً على \(targets.count) هدفاً")
        state.portResults.removeAll()
        var all: [PortResult] = []
        // التقاط الخدمة محلياً: إغلاقات addTask ‏@Sendable‏ فلا يجوز فيها
        // الإشارة الضمنية إلى self.
        let portService = state.portScan
        for host in targets {
            let results = await withTaskGroup(of: PortCheck.self) { group in
                for port in state.commonPorts {
                    group.addTask { await portService.check(host: host, port: port) }
                }
                var collected: [PortCheck] = []
                for await item in group { collected.append(item) }
                return collected
            }
            for check in results.sorted(by: { $0.port < $1.port }) {
                let result = PortResult(host: host, port: check.port, state: check.state, banner: check.banner, isDemo: false)
                all.append(result)
                if check.state == .open {
                    state.log.add(.success, category: "المنافذ", message: "\(host):\(check.port) مفتوح", detail: check.banner ?? "بلا لافتة")
                }
            }
            state.portResults = all
        }
        let open = all.filter { $0.state == .open }
        state.log.add(.info, category: "المنافذ", message: "انتهى فحص المنافذ: \(open.count) مفتوحاً من \(all.count) مفحوصاً")
        state.hasScanned = true
        state.isScanning = false
        state.scanStatus = ""
    }

    // MARK: - Bonjour

    func runBonjour(seconds: TimeInterval = 10) async {
        if state.demoMode {
            state.bonjour.clearServices()
            let demo = [
                BonjourServiceInfo(name: "Ford SYNC 4 (تجريبي)", type: "_airplay._tcp.", host: "192.168.1.10", port: 7000, isDemo: true),
                BonjourServiceInfo(name: "RAOP SYNC (تجريبي)", type: "_raop._tcp.", host: "192.168.1.10", port: 7001, isDemo: true)
            ]
            for service in demo {
                state.bonjour.addService(service)
                state.log.add(.success, category: "Bonjour", message: "تجريبي: \(service.name) — \(service.type) على \(service.host):\(service.port)")
            }
            state.hasScanned = true
            return
        }
        state.isScanning = true
        state.scanStatus = "جارٍ البحث عن خدمات Bonjour…"
        state.bonjour.onFound = { [weak self] info in
            Task { @MainActor [weak self] in
                self?.state.log.add(.success, category: "Bonjour", message: "وُجدت خدمة: \(info.name) — \(info.type)", detail: "\(info.host):\(info.port)")
            }
        }
        state.bonjour.onEvent = { [weak self] message, level in
            Task { @MainActor [weak self] in
                self?.state.log.add(level, category: "Bonjour", message: message)
            }
        }
        state.bonjour.start(types: state.bonjourTypes)
        state.log.add(.info, category: "Bonjour", message: "بدأ البحث عن خدمات Bonjour (\(state.bonjourTypes.count) أنواع) لمدة \(Int(seconds)) ثوانٍ")
        try? await Task.sleep(nanoseconds: UInt64(seconds * 1_000_000_000))
        state.bonjour.stop()
        state.log.add(.info, category: "Bonjour", message: "انتهى البحث: \(state.bonjour.services.count) خدمة مكتشفة")
        state.hasScanned = true
        state.isScanning = false
        state.scanStatus = ""
    }

    // MARK: - فحص HTTP

    func runHttpProbe() async {
        if state.demoMode {
            state.httpResults = [
                HttpProbeResult(url: "http://192.168.1.1:80/", statusCode: 200,
                                headers: [("Server", "DemoAirPlay/1.0"), ("Content-Type", "text/html")],
                                bodyPrefix: "<html><body>صفحة تجريبية وهمية — ليست من سيارة</body></html>",
                                error: nil, isDemo: true)
            ]
            state.log.add(.success, category: "HTTP", message: "تجريبي: http://192.168.1.1:80/ ردّ 200")
            state.hasScanned = true
            return
        }
        let targets = state.openPorts.filter { state.httpPorts.contains($0.port) }
        guard !targets.isEmpty else {
            state.log.add(.info, category: "HTTP", message: "لا منافذ HTTP مفتوحة لفحصها — شغّل فحص المنافذ أولاً")
            return
        }
        state.isScanning = true
        state.httpResults.removeAll()
        for target in targets {
            let outcome = await state.http.probe(host: target.host, port: target.port)
            let result = HttpProbeResult(
                url: "http://\(target.host):\(target.port)/",
                statusCode: outcome.statusCode, headers: outcome.headers,
                bodyPrefix: outcome.bodyPrefix, error: outcome.error, isDemo: false)
            state.httpResults.append(result)
            if let code = outcome.statusCode {
                state.log.add(.success, category: "HTTP", message: "\(result.url) — رمز \(code)", detail: "أول 2KB من الجسم مسجلة في النتيجة")
            } else {
                state.log.add(.warning, category: "HTTP", message: "\(result.url) — بلا رد HTTP", detail: outcome.error ?? "")
            }
        }
        state.hasScanned = true
        state.isScanning = false
    }

    // MARK: - فحص شامل + تجريبي

    func runAll() async {
        refreshNetwork()
        await runDiscovery()
        await runPortScan()
        await runBonjour(seconds: 10)
        await runHttpProbe()
        state.log.add(.info, category: "الخلاصة", message: "اكتمل الفحص الشامل — راجع شاشة الخلاصة والسجل")
    }

    func loadDemo() {
        state.demoMode = true
        state.hosts.removeAll()
        state.portResults.removeAll()
        state.httpResults.removeAll()
        state.hasScanned = false
        refreshNetwork()
        state.log.add(.warning, category: "تجريبي", message: "فُعّل الوضع التجريبي — كل النتائج التالية وهمية وموسومة")
    }

    func exitDemo() {
        state.demoMode = false
        state.hosts.removeAll()
        state.portResults.removeAll()
        state.httpResults.removeAll()
        state.bonjour.clearServices()
        state.network = .empty
        state.hasScanned = false
        state.log.add(.info, category: "تجريبي", message: "أُلغي الوضع التجريبي — أُفرغت النتائج الوهمية")
        refreshNetwork()
    }
}

// MARK: - Array chunking
private extension Array {
    func chunked(into size: Int) -> [[Element]] {
        guard size > 0 else { return [self] }
        var out: [[Element]] = []
        var index = 0
        while index < count {
            out.append(Array(self[index..<Swift.min(index + size, count)]))
            index += size
        }
        return out
    }
}
