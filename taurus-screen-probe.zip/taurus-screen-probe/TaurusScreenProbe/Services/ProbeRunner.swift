import Foundation

// MARK: - ProbeRunner
/// منسّق الفحص — يشغّل الأدوات بالترتيب ويكتب كل خطوة ونتيجتها الخام في السجل.
/// v1.1: واجهات متعددة، بوابة متعددة الطرق، فحص منافذ كامل، DNS-SD كامل،
/// SSDP، HTTP موسّع، TLS، تتبع مسار، وتشخيص عقبات عند كل فشل.
/// قراءة فقط بالكامل: فحص شبكة + قراءة لافتات، بلا أي محاولة دخول أو كتابة.

@MainActor
final class ProbeRunner {
    private let state: ProbeState

    init(state: ProbeState) {
        self.state = state
    }

    // MARK: - الشبكة الحالية

    func refreshNetwork() {
        if state.demoMode {
            state.network = NetworkInfo(
                ssid: "SYNC-4-DEMO", ssidAvailable: true, bssid: "AA:BB:CC:DD:EE:FF",
                localIP: "192.168.1.50", netmask: "255.255.255.0", interfaceName: "en0",
                interfaces: [
                    InterfaceInfo(name: "en0", ip: "192.168.1.50", netmask: "255.255.255.0", isUp: true, isActive: true),
                    InterfaceInfo(name: "awdl0", ip: "169.254.10.20", netmask: "255.255.0.0", isUp: true, isActive: false)
                ],
                gateway: "192.168.1.1", gatewaySource: .system,
                gatewayCandidates: [GatewayCandidate(ip: "192.168.1.1", source: "نطاق .1", responded: true, rttMs: 2.3, isDemo: true)],
                dnsServers: ["192.168.1.1"], isWiFi: true, isDemo: true)
            state.interfaces = state.network.interfaces
            state.gatewayCandidates = state.network.gatewayCandidates
            state.log.add(.info, category: "الشبكة", message: "وضع تجريبي: شبكة وهمية 192.168.1.0/24")
            return
        }
        let info = NetworkInfoService.readCurrent(isWiFi: state.pathWatcher.isWiFi)
        state.network = info
        state.interfaces = info.interfaces
        state.gatewayCandidates = info.gatewayCandidates
        if info.interfaces.isEmpty {
            state.addObstacle(category: "الشبكة", title: "لا واجهات شبكة ظاهرة",
                              cause: "getifaddrs لم يعطِ أي واجهة IPv4 مفعّلة — قد يكون Wi-Fi مطفأً أو بلا اتصال",
                              fix: "شغّل Wi-Fi من الإعدادات واتصل بشبكة الشاشة أولاً، ثم أعد قراءة الشبكة", level: .error)
        } else if let active = info.interfaces.first(where: { $0.isActive }) {
            state.log.add(.success, category: "الشبكة", message: "الواجهة النشطة: \(active.name) (\(active.kindLabelAr)) — \(active.ip ?? "بلا IP")",
                          detail: "واجهات مقروءة: \(info.interfaces.map { $0.name }.joined(separator: ", "))")
        }
        if info.localIP == nil {
            state.addObstacle(category: "الشبكة", title: "لا عنوان IP محلي",
                              cause: "الواجهة النشطة بلا عنوان IPv4 — الآيفون غير متصل بشبكة فعلاً",
                              fix: "اتصل بشبكة شاشة تورس من إعدادات Wi-Fi وانتظر ظهور عنوان IP", level: .error)
        }
        if info.ssidAvailable, let ssid = info.ssid {
            state.log.add(.info, category: "الشبكة", message: "اسم الشبكة (SSID): \(ssid)", detail: "BSSID: \(info.bssid ?? "غير متاح")")
        } else {
            state.addObstacle(category: "الشبكة", title: "اسم الشبكة غير متاح من iOS",
                              cause: "iOS تمنع قراءة SSID/BSSID بلا صلاحية Wi-Fi الخاصة (com.apple.developer.networking.wifi-info) — قيد من Apple وليس خللاً في التطبيق",
                              fix: "لا إصلاح داخل التطبيق؛ الفحص يعمل بدونه عبر عنوان IP والبوابة", level: .warning)
        }
        if info.dnsServers.isEmpty {
            state.log.add(.info, category: "الشبكة", message: "خوادم DNS غير مقروءة من النظام")
        } else {
            state.log.add(.info, category: "الشبكة", message: "خوادم DNS: \(info.dnsServers.joined(separator: ", "))")
        }
    }

    // MARK: - حلّ البوابة (متعدد الطرق)

    /// يفحص كل مرشح بوابة (.1 و.254) بردّ مباشر (ping ثم TCP:80)،
    /// وأول مرشح يردّ يصبح البوابة المؤكدة. بلا ردّ من أي مرشح تُسجَّل عقبة.
    func resolveGateway() async {
        if state.demoMode { return }
        guard !state.gatewayCandidates.isEmpty else {
            state.addObstacle(category: "البوابة", title: "لا مرشحي بوابة",
                              cause: "تعذر حساب النطاق — لا عنوان IP محلي مقروء",
                              fix: "اقرأ الشبكة الحالية أولاً بعد الاتصال بشبكة الشاشة", level: .error)
            return
        }
        let pingService = state.ping
        let portService = state.portScan
        var updated: [GatewayCandidate] = []
        for candidate in state.gatewayCandidates {
            var responded = false
            var rtt: Double? = nil
            switch await pingService.ping(host: candidate.ip) {
            case .replied(let ms):
                responded = true
                rtt = ms
            case .noReply:
                // بديل: اتصال TCP بالمنفذ 80.
                let check = await portService.check(host: candidate.ip, port: 80)
                responded = check.state == .open
            case .unavailable:
                let check = await portService.check(host: candidate.ip, port: 80)
                responded = check.state == .open
            }
            updated.append(GatewayCandidate(ip: candidate.ip, source: candidate.source, responded: responded, rttMs: rtt, isDemo: false))
            if responded {
                state.log.add(.success, category: "البوابة", message: "البوابة \(candidate.ip) ردّت (\(candidate.source))\(rtt.map { " — \(String(format: "%.1f", $0))ms" } ?? "")")
            } else {
                state.log.add(.warning, category: "البوابة", message: "المرشح \(candidate.ip) (\(candidate.source)) بلا ردّ")
            }
        }
        state.gatewayCandidates = updated
        state.network.gatewayCandidates = updated
        if let confirmed = updated.first(where: { $0.responded }) {
            state.network.gateway = confirmed.ip
            state.network.gatewaySource = .system
            state.log.add(.success, category: "البوابة", message: "البوابة المؤكدة بردّ مباشر: \(confirmed.ip)")
        } else {
            state.network.gatewaySource = .heuristic
            state.addObstacle(category: "البوابة", title: "لا مرشح بوابة ردّ على الفحص",
                              cause: "العناوين \(updated.map { $0.ip }.joined(separator: " و")) لم ترد على ping ولا TCP:80 — قد تكون الشاشة لا ترد على ping أصلاً، أو الآيفون ليس على شبكتها",
                              fix: "تأكد من اتصال الآيفون بشبكة الشاشة فعلاً (وليست شبكة المنزل)، ثم شغّل اكتشاف الأجهزة — فهو يجد أي جهاز يرد ولو لم تكن البوابة معروفة", level: .error)
        }
    }

    // MARK: - اكتشاف الأجهزة

    /// عناوين النطاق المحلي من IP + القناع (بحد أقصى 256 عنواناً).
    private func subnetHosts() -> [String]? {
        guard let ip = state.network.localIP, let mask = state.network.netmask else { return nil }
        let ipParts = ip.split(separator: ".").compactMap { UInt32($0) }
        let maskParts = mask.split(separator: ".").compactMap { UInt32($0) }
        guard ipParts.count == 4, maskParts.count == 4 else { return nil }
        func toInt(_ p: [UInt32]) -> UInt32 { (p[0] << 24) | (p[1] << 16) | (p[2] << 8) | p[3] }
        let ipNum = toInt(ipParts)
        let maskNum = toInt(maskParts)
        let networkNum = ipNum & maskNum
        let broadcastNum = networkNum | ~maskNum
        var hosts: [String] = []
        var n = networkNum + 1
        while n < broadcastNum && hosts.count < 256 {
            if n != ipNum {
                hosts.append("\((n >> 24) & 0xff).\((n >> 16) & 0xff).\((n >> 8) & 0xff).\(n & 0xff)")
            }
            n += 1
        }
        return hosts
    }

    func runDiscovery() async {
        guard !state.isScanning else { return }
        if state.demoMode {
            state.isScanning = true
            state.hosts = [
                DiscoveredHost(ip: "192.168.1.1", rttMs: 2.3, method: "ICMP ping", isGateway: true, hostname: "sync4.local", isDemo: true),
                DiscoveredHost(ip: "192.168.1.10", rttMs: 4.1, method: "ICMP ping", isGateway: false, hostname: nil, isDemo: true)
            ]
            state.log.add(.success, category: "اكتشاف", message: "تجريبي: جهازان يردان — 192.168.1.1 (البوابة) و192.168.1.10 (APIM وهمي)")
            state.hasScanned = true
            state.isScanning = false
            return
        }
        guard let targets = subnetHosts(), !targets.isEmpty else {
            state.addObstacle(category: "اكتشاف", title: "تعذر حساب نطاق الشبكة",
                              cause: "لا عنوان IP أو قناع مقروء — اقرأ الشبكة الحالية أولاً",
                              fix: "اتصل بشبكة الشاشة ثم أعد قراءة الشبكة قبل المسح", level: .error)
            return
        }
        state.isScanning = true
        state.scanStatus = "جارٍ مسح \(targets.count) عنواناً…"
        state.log.add(.info, category: "اكتشاف", message: "بدء مسح \(targets.count) عنواناً (ICMP ping، مهلة 1 ثانية)")
        state.hosts.removeAll()
        let gatewayIP = state.network.gateway
        // التقاط الخدمة محلياً: إغلاقات addTask ‏@Sendable‏ فلا يجوز فيها
        // الإشارة الضمنية إلى self (خطأ تجميع ظهر في مشروع التطبيق الحالي).
        let pingService = state.ping
        let portService = state.portScan
        var pingFailed = false
        var found: [DiscoveredHost] = []
        // دفعات متوازية من 32 عنواناً.
        for chunk in targets.chunked(into: 32) {
            let results = await withTaskGroup(of: (String, PingOutcome).self) { group in
                for ip in chunk {
                    group.addTask { (ip, await pingService.ping(host: ip)) }
                }
                var collected: [(String, PingOutcome)] = []
                for await item in group { collected.append(item) }
                return collected
            }
            for (ip, outcome) in results {
                switch outcome {
                case .replied(let rtt):
                    let host = DiscoveredHost(ip: ip, rttMs: rtt, method: "ICMP ping", isGateway: ip == gatewayIP, hostname: nil, isDemo: false)
                    found.append(host)
                    state.log.add(.success, category: "اكتشاف", message: "ردّ \(ip) — \(String(format: "%.1f", rtt))ms", detail: "ICMP ping")
                case .noReply:
                    break
                case .unavailable(let reason):
                    if !pingFailed {
                        pingFailed = true
                        state.log.add(.error, category: "اكتشاف", message: "تعذر ICMP ping: \(reason) — التبديل إلى فحص TCP:80 كبديل للاكتشاف", detail: "يُسجَّل البديل في كل نتيجة")
                    }
                    // بديل: اتصال TCP بالمنفذ 80 كدليل وجود.
                    let check = await portService.check(host: ip, port: 80)
                    if check.state == .open {
                        let host = DiscoveredHost(ip: ip, rttMs: nil, method: "TCP:80", isGateway: ip == gatewayIP, hostname: nil, isDemo: false)
                        found.append(host)
                        state.log.add(.success, category: "اكتشاف", message: "ردّ \(ip) عبر TCP:80 (بديل ICMP)", detail: "منفذ 80 مفتوح")
                    }
                }
            }
            state.hosts = found.sorted { $0.ip < $1.ip }
            state.scanStatus = "وُجد \(found.count) حتى الآن…"
        }
        // بحث DNS العكسي لكل جهاز وُجد (لتمييز اسم الشاشة إن أعلنته).
        if !found.isEmpty {
            let dns = DnsService()
            var enriched: [DiscoveredHost] = []
            for host in found {
                let name = await dns.reverseLookup(ip: host.ip)
                enriched.append(DiscoveredHost(ip: host.ip, rttMs: host.rttMs, method: host.method, isGateway: host.isGateway, hostname: name, isDemo: false))
                if let name {
                    state.log.add(.info, category: "اكتشاف", message: "\(host.ip) — اسم المضيف: \(name)")
                }
            }
            found = enriched
            state.hosts = found.sorted { $0.ip < $1.ip }
        }
        state.log.add(.info, category: "اكتشاف", message: "انتهى المسح: \(found.count) جهازاً يرد من \(targets.count) عنواناً")
        if found.isEmpty {
            state.addObstacle(category: "اكتشاف", title: "لا أجهزة ردّت على المسح",
                              cause: "كل عناوين النطاق بلا ردّ على ping وTCP:80 — غالباً الآيفون ليس على شبكة الشاشة، أو الشاشة توقفت عن البث، أو إذن الشبكة المحلية مرفوض فيصمت الفحص كله",
                              fix: "تحقق من الواي فاي (هل أنت على شبكة الشاشة؟)، ومن إذن الشبكة المحلية في الإعدادات، وأعد المسح أثناء بث الشاشة", level: .error)
        } else if let likely = state.likelyScreenDevice {
            state.log.add(.info, category: "اكتشاف", message: "جهاز الشاشة المرجح: \(likely.ip)\(likely.hostname.map { " (\($0))" } ?? "")")
        }
        state.hasScanned = true
        state.isScanning = false
        state.scanStatus = ""
    }

    // MARK: - فحص المنافذ

    func runPortScan(mode: PortScanMode? = nil) async {
        let scanMode = mode ?? state.portScanMode
        guard !state.isScanning else { return }
        if state.demoMode {
            state.isScanning = true
            state.portResults = [
                PortResult(host: "192.168.1.1", port: 80, state: .open, banner: "HTTP/1.1 200 OK\r\nServer: DemoAirPlay/1.0 (رد وهمي موسوم)", serviceName: "HTTP", isDemo: true),
                PortResult(host: "192.168.1.1", port: 443, state: .closed, banner: nil, serviceName: "HTTPS", isDemo: true),
                PortResult(host: "192.168.1.1", port: 53, state: .closed, banner: nil, serviceName: "DNS", isDemo: true),
                PortResult(host: "192.168.1.10", port: 7000, state: .open, banner: "AirPlay — تجريبي", serviceName: "AirPlay", isDemo: true),
                PortResult(host: "192.168.1.10", port: 7001, state: .open, banner: "RAOP — تجريبي", serviceName: "RAOP (صوت AirPlay)", isDemo: true),
                PortResult(host: "192.168.1.10", port: 8008, state: .open, banner: "Chromecast — تجريبي", serviceName: "Chromecast", isDemo: true)
            ]
            state.portScannedCount = 28
            state.portClosedCount = 25
            state.log.add(.success, category: "المنافذ", message: "تجريبي: 3 منافذ مفتوحة (80 على البوابة، 7000/7001 على 192.168.1.10)")
            state.hasScanned = true
            state.isScanning = false
            return
        }
        var targets = state.discoveredIPs
        if let gw = state.network.gateway, !targets.contains(gw) {
            targets.insert(gw, at: 0)
        }
        guard !targets.isEmpty else {
            state.addObstacle(category: "المنافذ", title: "لا أهداف لفحص المنافذ",
                              cause: "لا أجهزة مكتشفة ولا بوابة معروفة",
                              fix: "شغّل اكتشاف الأجهزة أولاً (أو حلّ البوابة) ثم أعد فحص المنافذ", level: .error)
            return
        }
        let ports: [Int]
        let fastService: PortScanService
        switch scanMode {
        case .quick:
            ports = state.commonPorts
            fastService = state.portScan
        case .full:
            ports = Array(1...65535)
            fastService = PortScanService(connectTimeout: 0.3, bannerTimeout: 0.5)
        }
        state.isScanning = true
        state.scanStatus = "جارٍ فحص المنافذ (\(scanMode.labelAr))…"
        state.log.add(.info, category: "المنافذ", message: "فحص \(ports.count) منفذاً على \(targets.count) هدفاً (\(scanMode.labelAr))")
        state.portResults.removeAll()
        state.portScannedCount = 0
        state.portClosedCount = 0
        var all: [PortResult] = []
        var scanned = 0
        var closed = 0
        // التقاط الخدمة محلياً: إغلاقات addTask ‏@Sendable‏ فلا يجوز فيها
        // الإشارة الضمنية إلى self.
        let portService = fastService
        for host in targets {
            for chunk in ports.chunked(into: scanMode == .full ? 512 : 64) {
                let results = await withTaskGroup(of: PortCheck.self) { group in
                    for port in chunk {
                        group.addTask { await portService.check(host: host, port: port) }
                    }
                    var collected: [PortCheck] = []
                    for await item in group { collected.append(item) }
                    return collected
                }
                for check in results.sorted(by: { $0.port < $1.port }) {
                    scanned += 1
                    if check.state != .open { closed += 1 }
                    // في الوضع الكامل تُحفظ المفتوحة فقط (65 ألف سطر تثقل الواجهة).
                    if check.state == .open || scanMode == .quick {
                        let result = PortResult(host: host, port: check.port, state: check.state, banner: check.banner, serviceName: check.serviceName, isDemo: false)
                        all.append(result)
                    }
                    if check.state == .open {
                        state.log.add(.success, category: "المنافذ", message: "\(host):\(check.port) مفتوح\(check.serviceName.map { " — \($0)" } ?? "")", detail: check.banner ?? "بلا لافتة")
                    }
                }
                state.portResults = all
                state.portScannedCount = scanned
                state.portClosedCount = closed
                if scanMode == .full {
                    state.scanStatus = "فُحص \(scanned) من \(ports.count * targets.count)…"
                }
            }
        }
        let open = all.filter { $0.state == .open }
        state.log.add(.info, category: "المنافذ", message: "انتهى فحص المنافذ: \(open.count) مفتوحاً من \(scanned) مفحوصاً")
        if open.isEmpty {
            state.addObstacle(category: "المنافذ", title: "كل المنافذ المفحوصة مغلقة أو بلا ردّ",
                              cause: "فحص \(scanned) منفذاً على \(targets.count) هدفاً بلا منفذ مفتوح واحد — إما أن الشاشة لا تكشف أي خدمة TCP، أو أن جداراً يصفّي الاتصالات، أو أن الأهداف المقصودة ليست الشاشة",
                              fix: "تحقق أن الهدف هو عنوان الشاشة فعلاً (أول جهاز ردّ في الاكتشاف)، وجرّب فحص المنافذ الكامل إن كنت في الوضع السريع", level: .error)
        }
        state.hasScanned = true
        state.isScanning = false
        state.scanStatus = ""
    }

    // MARK: - Bonjour (DNS-SD كامل)

    func runBonjour(seconds: TimeInterval = 10) async {
        if state.demoMode {
            state.bonjour.clearServices()
            state.discoveredServiceTypes = ["_airplay._tcp.", "_raop._tcp.", "_http._tcp."]
            let demo = [
                BonjourServiceInfo(name: "Ford SYNC 4 (تجريبي)", type: "_airplay._tcp.", host: "192.168.1.10", port: 7000, isDemo: true),
                BonjourServiceInfo(name: "RAOP SYNC (تجريبي)", type: "_raop._tcp.", host: "192.168.1.10", port: 7001, isDemo: true)
            ]
            for service in demo {
                state.bonjour.addService(service)
                state.log.add(.success, category: "Bonjour", message: "تجريبي: \(service.name) — \(service.type) على \(service.host):\(service.port)")
            }
            state.hasScanned = true
            return
        }
        state.isScanning = true
        state.scanStatus = "جارٍ البحث عن خدمات Bonjour…"
        var searchFailed = false
        var failureCode: Int? = nil
        state.bonjour.onSearchFailed = { code in
            searchFailed = true
            failureCode = code
        }
        state.bonjour.onFound = { [weak self] info in
            Task { @MainActor [weak self] in
                self?.state.log.add(.success, category: "Bonjour", message: "وُجدت خدمة: \(info.name) — \(info.type)", detail: "\(info.host):\(info.port)")
            }
        }
        state.bonjour.onEvent = { [weak self] message, level in
            Task { @MainActor [weak self] in
                self?.state.log.add(level, category: "Bonjour", message: message)
            }
        }
        // أولاً: سرد كل أنواع الخدمات المعلنة على الشبكة (DNS-SD).
        let announced = await state.bonjour.enumerateServiceTypes(seconds: 6)
        state.discoveredServiceTypes = announced
        if !announced.isEmpty {
            state.log.add(.success, category: "Bonjour", message: "أنواع الخدمات المعلنة: \(announced.joined(separator: ", "))")
        } else {
            state.log.add(.warning, category: "Bonjour", message: "استعلام DNS-SD لم يسرد أي نوع خدمة معلن")
        }
        // ثانياً: البحث عن الأنواع المعلنة + القائمة الاحتياطية المعروفة.
        var types = Set(state.bonjourTypes)
        types.formUnion(announced)
        state.bonjour.start(types: Array(types))
        state.log.add(.info, category: "Bonjour", message: "بدأ البحث عن خدمات Bonjour (\(types.count) نوعاً) لمدة \(Int(seconds)) ثوانٍ")
        try? await Task.sleep(nanoseconds: UInt64(seconds * 1_000_000_000))
        state.bonjour.stop()
        if searchFailed {
            state.localNetworkPermission = .denied
            state.permissionErrorCode = failureCode
            state.addObstacle(category: "Bonjour", title: "فشل البحث عن خدمات Bonjour (رمز \(failureCode.map { "\($0)" } ?? "؟"))",
                              cause: "iOS رفضت البحث — غالباً إذن الشبكة المحلية مرفوض، فكل عمليات الشبكة المحلية تصمت بلا نتيجة",
                              fix: "افتح إعدادات الآيفون ← فاحص الشاشة ← فعّل «الشبكة المحلية»، ثم أعد البحث", level: .error)
        } else {
            state.localNetworkPermission = .granted
            state.log.add(.info, category: "Bonjour", message: "انتهى البحث: \(state.bonjour.services.count) خدمة مكتشفة")
            if state.bonjour.services.isEmpty {
                state.addObstacle(category: "Bonjour", title: "لم تُكتشف أي خدمة Bonjour",
                                  cause: "لا خدمة معلنة ردّت خلال البحث — الشاشة قد لا تعلن خدمات mDNS أصلاً، أو أن البحث جرى قبل اتصال CarPlay",
                                  fix: "أعد البحث أثناء اتصال CarPlay النشط بالشاشة، وتحقق من قسم أنواع الخدمات المعلنة أعلاه", level: .warning)
            }
        }
        state.hasScanned = true
        state.isScanning = false
        state.scanStatus = ""
    }

    // MARK: - SSDP/UPnP

    func runSsdp() async {
        if state.demoMode {
            state.ssdpServices = [
                SsdpServiceInfo(location: "http://192.168.1.10:7000/device.xml", server: "DemoAirPlay/1.0 UPnP/1.0", usn: "uuid:demo-airplay::upnp:rootdevice", searchTarget: "upnp:rootdevice", sourceIP: "192.168.1.10", isDemo: true)
            ]
            state.log.add(.success, category: "SSDP", message: "تجريبي: خدمة UPnP وهمية — DemoAirPlay على 192.168.1.10")
            state.hasScanned = true
            return
        }
        state.isScanning = true
        state.scanStatus = "جارٍ البحث عن خدمات UPnP/SSDP…"
        let services = await state.ssdp.discover(localIP: state.network.localIP)
        state.ssdpServices = services
        for service in services {
            state.log.add(.success, category: "SSDP", message: "خدمة UPnP: \(service.server) — \(service.location)", detail: "من \(service.sourceIP) — USN: \(service.usn)")
        }
        state.log.add(.info, category: "SSDP", message: "انتهى بحث SSDP: \(services.count) خدمة")
        if services.isEmpty {
            state.addObstacle(category: "SSDP", title: "لا خدمات UPnP/SSDP ردّت",
                              cause: "لا جهاز ردّ على M-SEARCH — الشاشة قد لا تعلن UPnP أصلاً (الأكثر احتمالاً)، أو إذن الشبكة المحلية مرفوض",
                              fix: "هذه النتيجة بحد ذاتها معلومة: غياب UPnP يعني أن الشاشة لا تكشف خدمات تحكم شبكية. تحقق من إذن الشبكة المحلية إن كانت بقية الفحوصات فارغة أيضاً", level: .warning)
        }
        state.hasScanned = true
        state.isScanning = false
        state.scanStatus = ""
    }

    // MARK: - فحص HTTP موسّع

    func runHttpProbe() async {
        if state.demoMode {
            state.httpResults = [
                HttpProbeResult(url: "http://192.168.1.1:80/", path: "/", method: "GET", statusCode: 200,
                                headers: [("Server", "DemoAirPlay/1.0"), ("Content-Type", "text/html")],
                                bodyPrefix: "<html><body>صفحة تجريبية وهمية — ليست من سيارة</body></html>",
                                allowedMethods: nil, error: nil, isDemo: true)
            ]
            state.log.add(.success, category: "HTTP", message: "تجريبي: http://192.168.1.1:80/ ردّ 200")
            state.hasScanned = true
            return
        }
        let targets = state.openPorts.filter { state.httpPorts.contains($0.port) }
        guard !targets.isEmpty else {
            state.addObstacle(category: "HTTP", title: "لا منافذ HTTP مفتوحة لفحصها",
                              cause: "فحص المنافذ لم يجد منفذ HTTP مفتوحاً على أي هدف",
                              fix: "شغّل فحص المنافذ أولاً؛ وإن كان مغلقاً كله فلا خادم HTTP مكشوف على الشاشة", level: .warning)
            return
        }
        state.isScanning = true
        state.httpResults.removeAll()
        let httpService = state.http
        for target in targets {
            // GET وHEAD للمسار الجذر، وOPTIONS لسرد الطرق المسموحة.
            let root = await httpService.probe(host: target.host, port: target.port, path: "/", method: "GET")
            state.httpResults.append(HttpProbeResult(url: "http://\(target.host):\(target.port)/", path: "/", method: "GET",
                                                     statusCode: root.statusCode, headers: root.headers, bodyPrefix: root.bodyPrefix,
                                                     allowedMethods: nil, error: root.error, isDemo: false))
            logHttpResult(host: target.host, port: target.port, path: "/", method: "GET", outcome: root)
            let options = await httpService.probe(host: target.host, port: target.port, path: "/", method: "OPTIONS")
            if let allowed = options.allowedMethods, !allowed.isEmpty {
                state.log.add(.info, category: "HTTP", message: "\(target.host):\(target.port) — الطرق المسموحة: \(allowed)")
                if let last = state.httpResults.last {
                    state.httpResults[state.httpResults.count - 1] = HttpProbeResult(
                        url: last.url, path: last.path, method: last.method, statusCode: last.statusCode,
                        headers: last.headers, bodyPrefix: last.bodyPrefix, allowedMethods: allowed, error: last.error, isDemo: false)
                }
            }
            // GET للمسارات الشائعة.
            for path in state.httpPaths where path != "/" {
                let outcome = await httpService.probe(host: target.host, port: target.port, path: path, method: "GET")
                state.httpResults.append(HttpProbeResult(url: "http://\(target.host):\(target.port)\(path)", path: path, method: "GET",
                                                         statusCode: outcome.statusCode, headers: outcome.headers, bodyPrefix: outcome.bodyPrefix,
                                                         allowedMethods: nil, error: outcome.error, isDemo: false))
                logHttpResult(host: target.host, port: target.port, path: path, method: "GET", outcome: outcome)
            }
        }
        let responded = state.httpResults.filter { $0.statusCode != nil }.count
        if responded == 0 {
            state.addObstacle(category: "HTTP", title: "لا ردّ HTTP من أي منفذ مفتوح",
                              cause: "المنافذ المفتوحة لا ترد على طلبات HTTP — قد تكون خدمات غير HTTP (مثل AirPlay الثنائي) أو ترفض الطلبات بلا ردّ",
                              fix: "راجع لافتات المنافذ في شاشة المنافذ — فهي تحدد نوع الخدمة الفعلي", level: .warning)
        }
        state.hasScanned = true
        state.isScanning = false
    }

    private func logHttpResult(host: String, port: Int, path: String, method: String, outcome: HttpProbeOutcome) {
        if let code = outcome.statusCode {
            state.log.add(.success, category: "HTTP", message: "\(method) http://\(host):\(port)\(path) — رمز \(code)", detail: "أول 2KB من الجسم مسجلة في النتيجة")
        } else {
            state.log.add(.warning, category: "HTTP", message: "\(method) http://\(host):\(port)\(path) — بلا رد HTTP", detail: outcome.error ?? "")
        }
    }

    // MARK: - شهادات TLS

    func runTls() async {
        if state.demoMode {
            state.tlsResults = [
                TlsCertificateInfo(host: "192.168.1.10", port: 443, subject: "Demo SYNC 4 (تجريبي)",
                                   issuer: "CN=Demo CA (تجريبي)", expiresAt: "2027-01-01",
                                   fingerprintSHA256: "demo-fingerprint-00000000000000000000000000000000", isDemo: true)
            ]
            state.log.add(.success, category: "TLS", message: "تجريبي: شهادة وهمية على 192.168.1.10:443")
            state.hasScanned = true
            return
        }
        let targets = state.openPorts.filter { $0.port == 443 || $0.port == 8443 }
        guard !targets.isEmpty else {
            state.log.add(.info, category: "TLS", message: "لا منافذ TLS مفتوحة (443/8443) لقراءة شهاداتها")
            return
        }
        state.isScanning = true
        for target in targets {
            if let cert = await state.tls.probe(host: target.host, port: target.port) {
                state.tlsResults.append(cert)
                state.log.add(.success, category: "TLS", message: "شهادة \(target.host):\(target.port) — الموضوع: \(cert.subject)",
                              detail: "المُصدِر: \(cert.issuer) — تنتهي: \(cert.expiresAt) — البصمة: \(cert.fingerprintSHA256.prefix(16))…")
            } else {
                state.log.add(.warning, category: "TLS", message: "المنفذ \(target.host):\(target.port) مفتوح لكن بلا شهادة مقروءة من المصافحة")
            }
        }
        if state.tlsResults.isEmpty {
            state.addObstacle(category: "TLS", title: "لا شهادات TLS مقروءة",
                              cause: "المنافذ المشفرة المفتوحة لم تقدّم شهادة قابلة للقراءة من المصافحة",
                              fix: "راجع لافتة المنفذ — قد لا تكون خدمة TLS أصلاً رغم رقم المنفذ", level: .warning)
        }
        state.hasScanned = true
        state.isScanning = false
    }

    // MARK: - تتبع المسار

    func runTraceroute() async {
        if state.demoMode {
            state.traceHops = [
                TraceHop(ttl: 1, ip: "192.168.1.1", rttMs: 2.1, isDemo: true)
            ]
            state.log.add(.success, category: "تتبع", message: "تجريبي: قفزة واحدة إلى البوابة 192.168.1.1")
            state.hasScanned = true
            return
        }
        guard let gateway = state.network.gateway else {
            state.addObstacle(category: "تتبع", title: "لا بوابة لتتبع المسار إليها",
                              cause: "عنوان البوابة غير معروف — اقرأ الشبكة وحلّ البوابة أولاً",
                              fix: "شغّل قراءة الشبكة وحلّ البوابة ثم أعد التتبع", level: .warning)
            return
        }
        state.isScanning = true
        state.scanStatus = "جارٍ تتبع المسار إلى \(gateway)…"
        let hops = await state.traceroute.trace(host: gateway)
        state.traceHops = hops
        for hop in hops {
            state.log.add(.info, category: "تتبع", message: "قفزة \(hop.ttl): \(hop.statusAr)\(hop.rttMs.map { " — \(String(format: "%.1f", $0))ms" } ?? "")")
        }
        if hops.isEmpty {
            state.addObstacle(category: "تتبع", title: "تعذر إنشاء مقبس ICMP للتتبع",
                              cause: "فشل إنشاء مقبس التتبع على الجهاز",
                              fix: "أعد المحاولة؛ وإن تكرر فالتتبع غير متاح على هذا الجهاز", level: .warning)
        }
        state.hasScanned = true
        state.isScanning = false
        state.scanStatus = ""
    }

    // MARK: - فحص شامل + تجريبي

    func runAll() async {
        refreshNetwork()
        await resolveGateway()
        await runDiscovery()
        await runPortScan(mode: .quick)
        await runBonjour(seconds: 10)
        await runSsdp()
        await runHttpProbe()
        await runTls()
        await runTraceroute()
        state.log.add(.info, category: "الخلاصة", message: "اكتمل الفحص الشامل — راجع شاشة الخلاصة والسجل")
        if !state.obstacles.isEmpty {
            state.log.add(.warning, category: "الخلاصة", message: "سُجلت \(state.obstacles.count) عقبة — راجع قسم العقبات في الخلاصة والسجل")
        }
    }

    func loadDemo() {
        state.demoMode = true
        state.hosts.removeAll()
        state.portResults.removeAll()
        state.httpResults.removeAll()
        state.ssdpServices.removeAll()
        state.tlsResults.removeAll()
        state.traceHops.removeAll()
        state.discoveredServiceTypes.removeAll()
        state.clearObstacles()
        state.localNetworkPermission = .granted
        state.hasScanned = false
        refreshNetwork()
        state.log.add(.warning, category: "تجريبي", message: "فُعّل الوضع التجريبي — كل النتائج التالية وهمية وموسومة")
    }

    func exitDemo() {
        state.demoMode = false
        state.hosts.removeAll()
        state.portResults.removeAll()
        state.httpResults.removeAll()
        state.ssdpServices.removeAll()
        state.tlsResults.removeAll()
        state.traceHops.removeAll()
        state.discoveredServiceTypes.removeAll()
        state.clearObstacles()
        state.localNetworkPermission = .notRequested
        state.permissionErrorCode = nil
        state.bonjour.clearServices()
        state.network = .empty
        state.interfaces = []
        state.gatewayCandidates = []
        state.hasScanned = false
        state.log.add(.info, category: "تجريبي", message: "أُلغي الوضع التجريبي — أُفرغت النتائج الوهمية")
        refreshNetwork()
    }
}

// MARK: - Array chunking
private extension Array {
    func chunked(into size: Int) -> [[Element]] {
        guard size > 0 else { return [self] }
        var out: [[Element]] = []
        var index = 0
        while index < count {
            out.append(Array(self[index..<Swift.min(index + size, count)]))
            index += size
        }
        return out
    }
}
