import Foundation

// MARK: - SsdpService
/// اكتشاف SSDP/UPnP: إرسال M-SEARCH متعدد البث إلى 239.255.255.250:1900
/// وقراءة الردود (LOCATION وSERVER وUSN وST) — قراءة فقط.
/// ملاحظة: الإرسال المتعدد البث يحتاج إذن الشبكة المحلية؛ إن رُفض الإذن
/// يفشل الإرسال وتُسجَّل عقبة بدل نتيجة وهمية.

final class SsdpService: Sendable {
    private let multicastIP = "239.255.255.250"
    private let multicastPort: UInt16 = 1900

    /// يرسل M-SEARCH بهدفين (ssdp:all ثم upnp:rootdevice) ويجمع الردود.
    /// يعيد الخدمات المكتشفة (بلا تكرار حسب USN).
    func discover(localIP: String?, timeout: TimeInterval = 4) async -> [SsdpServiceInfo] {
        await withCheckedContinuation { cont in
            DispatchQueue.global(qos: .userInitiated).async {
                cont.resume(returning: self.discoverSync(localIP: localIP, timeout: timeout))
            }
        }
    }

    private func discoverSync(localIP: String?, timeout: TimeInterval) -> [SsdpServiceInfo] {
        var found: [String: SsdpServiceInfo] = [:]
        for target in ["ssdp:all", "upnp:rootdevice"] {
            let batch = msearchSync(localIP: localIP, searchTarget: target, timeout: timeout)
            for service in batch {
                found[service.usn] = service
            }
        }
        return Array(found.values).sorted { $0.sourceIP < $1.sourceIP }
    }

    private func msearchSync(localIP: String?, searchTarget: String, timeout: TimeInterval) -> [SsdpServiceInfo] {
        let fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)
        guard fd >= 0 else { return [] }
        defer { close(fd) }

        // إرسال البث المتعدد من واجهة Wi-Fi نفسها (عنوان الآيفون المحلي).
        if let localIP, !localIP.isEmpty {
            var mcastIf = in_addr(s_addr: inet_addr(localIP))
            setsockopt(fd, IPPROTO_IP, IP_MULTICAST_IF, &mcastIf, socklen_t(MemoryLayout<in_addr>.size))
        }
        // ملاحظة: tv_usec نوعه __darwin_suseconds_t (Int32) لا Int — تحويل صريح
        // (كان خطأ تجميع التشغيل 10).
        var tv = timeval(tv_sec: Int(timeout), tv_usec: Int32((timeout - Double(Int(timeout))) * 1_000_000))
        setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, socklen_t(MemoryLayout<timeval>.size))

        let request = "M-SEARCH * HTTP/1.1\r\nHOST: \(multicastIP):\(multicastPort)\r\nMAN: \"ns=01\"\r\nMX: 3\r\nST: \(searchTarget)\r\nUSER-AGENT: TaurusScreenProbe/1.1\r\n\r\n"
        var dest = sockaddr_in()
        dest.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
        dest.sin_family = sa_family_t(AF_INET)
        dest.sin_port = multicastPort.bigEndian
        dest.sin_addr.s_addr = inet_addr(multicastIP)
        let sent = request.withCString { cstr in
            withUnsafePointer(to: &dest) { destPtr in
                destPtr.withMemoryRebound(to: sockaddr.self, capacity: 1) { sockPtr in
                    sendto(fd, cstr, strlen(cstr), 0, sockPtr, socklen_t(MemoryLayout<sockaddr_in>.size))
                }
            }
        }
        guard sent > 0 else { return [] }

        var results: [SsdpServiceInfo] = []
        let deadline = Date().addingTimeInterval(timeout)
        while Date() < deadline {
            var buffer = [UInt8](repeating: 0, count: 2048)
            var from = sockaddr_in()
            var fromLen = socklen_t(MemoryLayout<sockaddr_in>.size)
            let count = withUnsafeMutablePointer(to: &from) { fromPtr in
                fromPtr.withMemoryRebound(to: sockaddr.self, capacity: 1) { sockPtr in
                    recvfrom(fd, &buffer, buffer.count, 0, sockPtr, &fromLen)
                }
            }
            guard count > 0 else { break }
            let text = String(decoding: buffer[..<count], as: UTF8.self)
            let headers = parseHeaders(text)
            guard let location = headers["location"], let usn = headers["usn"] else { continue }
            let sourceIP = inet_ntoa(from.sin_addr).map { String(cString: $0) } ?? "—"
            results.append(SsdpServiceInfo(
                location: location,
                server: headers["server"] ?? "غير معلن",
                usn: usn,
                searchTarget: headers["st"] ?? searchTarget,
                sourceIP: sourceIP,
                isDemo: false))
        }
        return results
    }

    /// يحلل ترويسات رد HTTP/1.1 إلى قاموس بمفاتيح صغيرة.
    private func parseHeaders(_ text: String) -> [String: String] {
        var out: [String: String] = [:]
        for line in text.components(separatedBy: "\r\n") {
            guard let colon = line.firstIndex(of: ":") else { continue }
            let key = line[..<colon].trimmingCharacters(in: .whitespaces).lowercased()
            let value = line[line.index(after: colon)...].trimmingCharacters(in: .whitespaces)
            out[key] = value
        }
        return out
    }
}
