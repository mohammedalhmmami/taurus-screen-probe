import CryptoKit
import Foundation
import Security

// MARK: - TlsProbeService
/// قراءة شهادة TLS من المصافحة فقط — بلا اتصال كامل وبلا دخول وبلا إرسال بيانات.
/// الطريقة: جلسة URLSession بمندوب يلتقط SecTrust عند تحدي المصادقة، ثم
/// يُسمح للمعالجة الافتراضية بالمتابعة (فتفشل على شهادة موقعة ذاتياً — لكن
/// الشهادة تكون قد التُقطت أصلاً). تُقرأ من الشهادة: الموضوع والمُصدِر
/// وتاريخ الانتهاء والبصمة SHA-256. كل حقل غير مقروء يُعرض «غير مقروء».
///
/// ملاحظة: لا تُستخدم هنا SecCertificateCopyValues ولا رموز kSecOID* —
/// لم تُحلّ في بناء Xcode 26 (التشغيل 13) رغم `import Security`، فالمُصدِر
/// وتاريخ الانتهاء يُقرآن من بايتات DER مباشرة بقارئ ASN.1 مبسّط أدناه.
/// ولا تُستخدم SecTrustGetCertificateAtIndex (مهملة منذ iOS 15) بل
/// SecTrustCopyCertificateChain الحديثة. وإطار Security مربوط صراحة في
/// project.pbxproj أيضاً.

final class TlsProbeService: NSObject, URLSessionDelegate {
    private let lock = NSLock()
    private var capturedTrust: SecTrust?
    private var finishedContinuation: CheckedContinuation<Void, Never>?

    /// يقرأ شهادة المنفذ TLS — يعيد nil إن لم تُقدَّم أي شهادة.
    func probe(host: String, port: Int, timeout: TimeInterval = 6) async -> TlsCertificateInfo? {
        capturedTrust = nil
        guard let url = URL(string: "https://\(host):\(port)/") else { return nil }
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = timeout
        config.timeoutIntervalForResource = timeout + 2
        let session = URLSession(configuration: config, delegate: self, delegateQueue: nil)
        let task = session.dataTask(with: url)
        task.resume()
        // انتظار انتهاء المهمة أو المهلة، أيهما أولاً.
        await withTaskGroup(of: Void.self) { group in
            group.addTask {
                await withCheckedContinuation { (cont: CheckedContinuation<Void, Never>) in
                    self.lock.lock()
                    self.finishedContinuation = cont
                    self.lock.unlock()
                }
            }
            group.addTask {
                try? await Task.sleep(nanoseconds: UInt64(timeout * 1_000_000_000))
                task.cancel()
                self.finishWaiting()
            }
            await group.next()
            group.cancelAll()
        }
        session.invalidateAndCancel()
        guard let trust = capturedTrust else { return nil }
        return extractInfo(trust: trust, host: host, port: port)
    }

    private func finishWaiting() {
        lock.lock()
        defer { lock.unlock() }
        finishedContinuation?.resume()
        finishedContinuation = nil
    }

    // MARK: URLSessionDelegate

    func urlSession(_ session: URLSession, didReceive challenge: URLAuthenticationChallenge,
                    completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        if let trust = challenge.protectionSpace.serverTrust {
            lock.lock()
            capturedTrust = trust
            lock.unlock()
        }
        // معالجة افتراضية: تفشل على شهادة غير موثوقة، لكن الشهادة التُقطت.
        completionHandler(.performDefaultHandling, nil)
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        finishWaiting()
    }

    // MARK: - استخراج حقول الشهادة

    private func extractInfo(trust: SecTrust, host: String, port: Int) -> TlsCertificateInfo? {
        guard let chain = SecTrustCopyCertificateChain(trust) as? [SecCertificate],
              let cert = chain.first else { return nil }
        let subject = (SecCertificateCopySubjectSummary(cert) as String?) ?? "غير مقروء"
        guard let der = SecCertificateCopyData(cert) as Data? else {
            return TlsCertificateInfo(host: host, port: port, subject: subject,
                                      issuer: "غير مقروء", expiresAt: "غير مقروء",
                                      fingerprintSHA256: "غير مقروء", isDemo: false)
        }
        let fields = certificateFields(der: der)
        let digest = SHA256.hash(data: der)
        let fingerprint = digest.map { String(format: "%02x", $0) }.joined()
        return TlsCertificateInfo(host: host, port: port, subject: subject,
                                  issuer: fields.issuer, expiresAt: fields.expiry,
                                  fingerprintSHA256: fingerprint, isDemo: false)
    }

    /// المُصدِر وتاريخ الانتهاء من بايتات DER للشهادة (X.509):
    /// Certificate = SEQUENCE { tbsCertificate SEQUENCE {
    ///   [0] version (اختياري)، serial، signature، issuer، validity، subject، … } }.
    private func certificateFields(der: Data) -> (issuer: String, expiry: String) {
        guard let outer = DER.readTLV(der, at: 0), outer.tag == 0x30,
              let tbs = DER.children(of: der, in: outer.content).first, tbs.tag == 0x30 else {
            return ("غير مقروء", "غير مقروء")
        }
        var kids = DER.children(of: der, in: tbs.content)
        if kids.first?.tag == 0xA0 { kids.removeFirst() } // نسخة [0] الاختيارية
        guard kids.count >= 4 else { return ("غير مقروء", "غير مقروء") }
        let issuerTLV = kids[2]
        let validityTLV = kids[3]
        // المُصدِر: Name = SEQUENCE من SETs، كل SET فيه SEQUENCE { OID، قيمة }.
        var parts: [String] = []
        for setTLV in DER.children(of: der, in: issuerTLV.content) {
            for attr in DER.children(of: der, in: setTLV.content) {
                let fields = DER.children(of: der, in: attr.content)
                if fields.count >= 2, let value = DER.stringValue(der, tlv: fields[1]) {
                    parts.append(value)
                }
            }
        }
        let issuer = parts.isEmpty ? "غير مقروء" : parts.joined(separator: ", ")
        // الصلاحية: notAfter هو الطفل الثاني في validity.
        let validityKids = DER.children(of: der, in: validityTLV.content)
        var expiry = "غير مقروء"
        if validityKids.count >= 2, let date = DER.timeString(der, tlv: validityKids[1]) {
            expiry = date
        }
        return (issuer, expiry)
    }
}

// MARK: - Minimal DER reader (X.509 only)
/// قارئ TLV مبسّط: وسوم بايت واحد وأطوال قصيرة/طويلة حتى 4 بايتات.
/// يكفي لبنية شهادة X.509؛ أي بايتات غير متوقعة تعيد nil بدل الانهيار.
private struct DERTLV {
    let tag: UInt8
    let content: Range<Int>
    let total: Range<Int>
}

private enum DER {
    static func readTLV(_ data: Data, at offset: Int) -> DERTLV? {
        guard offset + 2 <= data.count else { return nil }
        let tag = data[offset]
        var pos = offset + 1
        let firstLen = data[pos]
        pos += 1
        var length: Int
        if firstLen & 0x80 == 0 {
            length = Int(firstLen)
        } else {
            let n = Int(firstLen & 0x7F)
            guard n >= 1 && n <= 4 && pos + n <= data.count else { return nil }
            length = 0
            for i in 0..<n {
                length = (length << 8) | Int(data[pos + i])
            }
            pos += n
        }
        guard pos + length <= data.count else { return nil }
        return DERTLV(tag: tag, content: pos..<(pos + length), total: offset..<(pos + length))
    }

    static func children(of data: Data, in range: Range<Int>) -> [DERTLV] {
        var out: [DERTLV] = []
        var pos = range.lowerBound
        while pos < range.upperBound, let tlv = readTLV(data, at: pos) {
            out.append(tlv)
            pos = tlv.total.upperBound
        }
        return out
    }

    static func stringValue(_ data: Data, tlv: DERTLV) -> String? {
        let bytes = Data(data[tlv.content])
        switch tlv.tag {
        case 0x1E: // BMPString (UTF-16BE)
            return String(data: bytes, encoding: .utf16BigEndian)
        case 0x0C, 0x13, 0x16, 0x14: // UTF8 / Printable / IA5 / Teletex
            return String(data: bytes, encoding: .utf8) ?? String(data: bytes, encoding: .ascii)
        default:
            return nil
        }
    }

    /// UTCTime (0x17: YYMMDD...) أو GeneralizedTime (0x18: YYYYMMDD...) → yyyy-MM-dd.
    static func timeString(_ data: Data, tlv: DERTLV) -> String? {
        guard let text = String(data: Data(data[tlv.content]), encoding: .ascii) else { return nil }
        let digits = String(text.filter { $0.isNumber })
        if tlv.tag == 0x17 {
            guard digits.count >= 6 else { return nil }
            let yy = Int(String(digits.prefix(2))) ?? 0
            let year = yy < 50 ? 2000 + yy : 1900 + yy
            let month = Int(String(digits.dropFirst(2).prefix(2))) ?? 0
            let day = Int(String(digits.dropFirst(4).prefix(2))) ?? 0
            return String(format: "%04d-%02d-%02d", year, month, day)
        }
        if tlv.tag == 0x18 {
            guard digits.count >= 8 else { return nil }
            let year = Int(String(digits.prefix(4))) ?? 0
            let month = Int(String(digits.dropFirst(4).prefix(2))) ?? 0
            let day = Int(String(digits.dropFirst(6).prefix(2))) ?? 0
            return String(format: "%04d-%02d-%02d", year, month, day)
        }
        return nil
    }
}
