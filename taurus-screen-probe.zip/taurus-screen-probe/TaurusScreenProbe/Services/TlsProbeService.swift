import CryptoKit
import Foundation
import Security

// MARK: - TlsProbeService
/// قراءة شهادة TLS من المصافحة فقط — بلا اتصال كامل وبلا دخول وبلا إرسال بيانات.
/// الطريقة: جلسة URLSession بمندوب يلتقط SecTrust عند تحدي المصادقة، ثم
/// يُسمح للمعالجة الافتراضية بالمتابعة (فتفشل على شهادة موقعة ذاتياً — لكن
/// الشهادة تكون قد التُقطت أصلاً). تُقرأ من الشهادة: الموضوع والمُصدِر
/// وتاريخ الانتهاء والبصمة SHA-256. كل حقل غير مقروء يُعرض «غير مقروء».

final class TlsProbeService: NSObject, URLSessionDelegate {
    private let lock = NSLock()
    private var capturedTrust: SecTrust?
    private var finishedContinuation: CheckedContinuation<Void, Never>?

    /// يقرأ شهادة المنفذ TLS — يعيد nil إن لم تُقدَّم أي شهادة.
    func probe(host: String, port: Int, timeout: TimeInterval = 6) async -> TlsCertificateInfo? {
        capturedTrust = nil
        guard let url = URL(string: "https://\(host):\(port)/") else { return nil }
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = timeout
        config.timeoutIntervalForResource = timeout + 2
        let session = URLSession(configuration: config, delegate: self, delegateQueue: nil)
        let task = session.dataTask(with: url)
        task.resume()
        // انتظار انتهاء المهمة أو المهلة، أيهما أولاً.
        await withTaskGroup(of: Void.self) { group in
            group.addTask {
                await withCheckedContinuation { (cont: CheckedContinuation<Void, Never>) in
                    self.lock.lock()
                    self.finishedContinuation = cont
                    self.lock.unlock()
                }
            }
            group.addTask {
                try? await Task.sleep(nanoseconds: UInt64(timeout * 1_000_000_000))
                task.cancel()
                self.finishWaiting()
            }
            await group.next()
            group.cancelAll()
        }
        session.invalidateAndCancel()
        guard let trust = capturedTrust else { return nil }
        return extractInfo(trust: trust, host: host, port: port)
    }

    private func finishWaiting() {
        lock.lock()
        defer { lock.unlock() }
        finishedContinuation?.resume()
        finishedContinuation = nil
    }

    // MARK: URLSessionDelegate

    func urlSession(_ session: URLSession, didReceive challenge: URLAuthenticationChallenge,
                    completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        if let trust = challenge.protectionSpace.serverTrust {
            lock.lock()
            capturedTrust = trust
            lock.unlock()
        }
        // معالجة افتراضية: تفشل على شهادة غير موثوقة، لكن الشهادة التُقطت.
        completionHandler(.performDefaultHandling, nil)
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        finishWaiting()
    }

    // MARK: - استخراج حقول الشهادة

    private func extractInfo(trust: SecTrust, host: String, port: Int) -> TlsCertificateInfo? {
        guard SecTrustGetCertificateCount(trust) > 0,
              let cert = SecTrustGetCertificateAtIndex(trust, 0) else { return nil }
        let subject = (SecCertificateCopySubjectSummary(cert) as String?) ?? "غير مقروء"
        let issuer = issuerName(of: cert)
        let expiry = expiryDate(of: cert)
        let fingerprint = fingerprintSHA256(of: cert)
        return TlsCertificateInfo(
            host: host, port: port,
            subject: subject,
            issuer: issuer,
            expiresAt: expiry,
            fingerprintSHA256: fingerprint,
            isDemo: false)
    }

    private func issuerName(of cert: SecCertificate) -> String {
        guard let values = SecCertificateCopyValues(cert, [kSecOIDX509V1IssuerName] as CFArray, nil) as? [String: Any],
              let entry = values[kSecOIDX509V1IssuerName as String] as? [String: Any],
              let rdns = entry[kSecPropertyKeyValue as String] as? [[String: Any]] else {
            return "غير مقروء"
        }
        var parts: [String] = []
        for rdn in rdns {
            if let label = rdn[kSecPropertyKeyLabel as String] as? String,
               let value = rdn[kSecPropertyKeyValue as String] as? String {
                parts.append("\(label)=\(value)")
            }
        }
        return parts.isEmpty ? "غير مقروء" : parts.joined(separator: ", ")
    }

    private func expiryDate(of cert: SecCertificate) -> String {
        guard let values = SecCertificateCopyValues(cert, [kSecOIDX509V1ValidityNotAfter] as CFArray, nil) as? [String: Any],
              let entry = values[kSecOIDX509V1ValidityNotAfter as String] as? [String: Any],
              let date = entry[kSecPropertyKeyValue as String] as? Date else {
            return "غير مقروء"
        }
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: date)
    }

    private func fingerprintSHA256(of cert: SecCertificate) -> String {
        guard let der = SecCertificateCopyData(cert) as Data? else { return "غير مقروء" }
        let digest = SHA256.hash(data: der)
        return digest.map { String(format: "%02x", $0) }.joined()
    }
}
