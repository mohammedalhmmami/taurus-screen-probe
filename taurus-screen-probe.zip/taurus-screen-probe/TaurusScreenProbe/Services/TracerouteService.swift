import Foundation

// MARK: - TracerouteService
/// تتبع المسار عبر ICMP echo مع TTL متزايد — نفس مقبس datagram المستخدم
/// في PingService (SOCK_DGRAM مع IPPROTO_ICMP، بلا صلاحيات جذر).
/// كل قفزة: إرسال echo بTTL محدد؛ إن ردّ موجّه بـ «تجاوز الوقت» (نوع 11)
/// فعنوان المرسل هو القفزة؛ وإن ردّ echo (نوع 0) فقد وصلنا إلى الهدف.
/// ملاحظة صريحة: iOS لا تكشف عناوين الموجّهات الوسيطة إلا إن ردّت هي
/// نفسها برسالة ICMP — الموجّه الصامت يظهر «لا يرد»، وهذا قيد من الشبكة
/// لا خلل في التطبيق. للشبكة المحلية (بوابة على بعد قفزة واحدة) يكفي هذا.

final class TracerouteService: Sendable {
    private let perHopTimeout: TimeInterval
    private let maxHops: Int

    init(perHopTimeout: TimeInterval = 1.0, maxHops: Int = 16) {
        self.perHopTimeout = perHopTimeout
        self.maxHops = maxHops
    }

    /// يتتبع المسار إلى الهدف ويعيد القفزات بالترتيب.
    func trace(host: String) async -> [TraceHop] {
        await withCheckedContinuation { cont in
            DispatchQueue.global(qos: .userInitiated).async {
                cont.resume(returning: self.traceSync(host: host))
            }
        }
    }

    private func traceSync(host: String) -> [TraceHop] {
        let fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_ICMP)
        guard fd >= 0 else { return [] }
        defer { close(fd) }
        var tv = timeval(tv_sec: Int(perHopTimeout), tv_usec: 0)
        setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, socklen_t(MemoryLayout<timeval>.size))

        var addr = sockaddr_in()
        addr.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
        addr.sin_family = sa_family_t(AF_INET)
        addr.sin_addr.s_addr = inet_addr(host)
        guard addr.sin_addr.s_addr != INADDR_NONE else { return [] }

        let identifier = UInt16.random(in: 1...UInt16.max)
        var hops: [TraceHop] = []

        for ttl in 1...maxHops {
            var ttlValue = Int32(ttl)
            setsockopt(fd, IPPROTO_IP, IP_TTL, &ttlValue, socklen_t(MemoryLayout<Int32>.size))

            var packet = Data()
            packet.append(8) // ICMP echo request
            packet.append(0)
            packet.append(contentsOf: [0, 0])
            packet.append(contentsOf: withUnsafeBytes(of: identifier.bigEndian) { Array($0) })
            packet.append(contentsOf: withUnsafeBytes(of: UInt16(ttl).bigEndian) { Array($0) })
            packet.append(contentsOf: "TaurusTrace".utf8)
            let sum = internetChecksum(packet)
            packet[2] = UInt8(sum >> 8)
            packet[3] = UInt8(sum & 0xff)

            let sent = packet.withUnsafeBytes { ptr in
                withUnsafePointer(to: &addr) { addrPtr in
                    addrPtr.withMemoryRebound(to: sockaddr.self, capacity: 1) { sockPtr in
                        sendto(fd, ptr.baseAddress, packet.count, 0, sockPtr, socklen_t(MemoryLayout<sockaddr_in>.size))
                    }
                }
            }
            guard sent == packet.count else {
                hops.append(TraceHop(ttl: ttl, ip: nil, rttMs: nil, isDemo: false))
                continue
            }

            let start = Date()
            var buffer = [UInt8](repeating: 0, count: 1024)
            var from = sockaddr_in()
            var fromLen = socklen_t(MemoryLayout<sockaddr_in>.size)
            let received = withUnsafeMutablePointer(to: &from) { fromPtr in
                fromPtr.withMemoryRebound(to: sockaddr.self, capacity: 1) { sockPtr in
                    recvfrom(fd, &buffer, buffer.count, 0, sockPtr, &fromLen)
                }
            }
            let rtt = Date().timeIntervalSince(start) * 1000
            guard received > 0 else {
                hops.append(TraceHop(ttl: ttl, ip: nil, rttMs: nil, isDemo: false))
                continue
            }
            let ihl = Int(buffer[0] & 0x0f) * 4
            guard received >= ihl + 8 else {
                hops.append(TraceHop(ttl: ttl, ip: nil, rttMs: nil, isDemo: false))
                continue
            }
            let icmpType = buffer[ihl]
            let hopIP = inet_ntoa(from.sin_addr).map { String(cString: $0) }
            hops.append(TraceHop(ttl: ttl, ip: hopIP, rttMs: rtt, isDemo: false))
            if icmpType == 0 {
                // رد echo — وصلنا إلى الهدف، انتهى التتبع.
                break
            }
            // نوع 11 (تجاوز الوقت) أو غيره: قفزة وسيطة، أكمل للقفزة التالية.
        }
        return hops
    }

    /// تشيكسم الإنترنت القياسي (مكمل الواحد لمجموع الكلمات 16 بت).
    private func internetChecksum(_ data: Data) -> UInt16 {
        let bytes = [UInt8](data)
        var sum: UInt32 = 0
        var i = 0
        while i + 1 < bytes.count {
            sum += UInt32(bytes[i]) << 8 | UInt32(bytes[i + 1])
            i += 2
        }
        if i < bytes.count {
            sum += UInt32(bytes[i]) << 8
        }
        while (sum >> 16) != 0 {
            sum = (sum & 0xffff) + (sum >> 16)
        }
        return ~UInt16(sum & 0xffff)
    }
}
