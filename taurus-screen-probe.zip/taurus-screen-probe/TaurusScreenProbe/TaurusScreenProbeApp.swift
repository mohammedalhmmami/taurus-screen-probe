import SwiftUI

// MARK: - TaurusScreenProbeApp
/// نقطة دخول «فاحص شاشة تورس» — تجربة فحص قراءة فقط لشبكة الواي فاي
/// التي تبثها شاشة SYNC 4 (شبكة CarPlay).
/// صراحة من البداية: هذه الشبكة غالباً شبكة وسائط وليست بوابة لشبكة السيارة CAN،
/// والتطبيق يسجّل ما يرد فعلاً فقط ولا يخترع نتائج.

@main
struct TaurusScreenProbeApp: App {
    @StateObject private var state = ProbeState()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(state)
                .preferredColorScheme(.dark)
                .environment(\.layoutDirection, .rightToLeft)
        }
    }
}

// MARK: - ProbeDestination
/// وجهات شبكة الأيقونات الرئيسية.
enum ProbeDestination: String, CaseIterable, Hashable {
    case network = "الشبكة الحالية"
    case discovery = "اكتشاف الأجهزة"
    case ports = "فحص المنافذ"
    case bonjour = "خدمات Bonjour"
    case http = "فحص HTTP"
    case log = "السجل"
    case summary = "الخلاصة"
    case map = "خارطة الشبكة"

    var iconName: String {
        switch self {
        case .network: return "wifi"
        case .discovery: return "antenna.radiowaves.left.and.right"
        case .ports: return "network"
        case .bonjour: return "airplayaudio"
        case .http: return "globe"
        case .log: return "list.clipboard"
        case .summary: return "doc.text.magnifyingglass"
        case .map: return "map"
        }
    }
}
