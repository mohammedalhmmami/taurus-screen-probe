import SwiftUI

// MARK: - BonjourView
/// خدمات Bonjour — البحث عن خدمات mDNS المعلنة (AirPlay وRAOP وHTTP وغيرها)
/// وتسجيل كل خدمة تُكتشف باسمها وعنوانها ومنفذها.

struct BonjourView: View {
    @EnvironmentObject var state: ProbeState

    var body: some View {
        List {
            Section {
                Text("يبحث أولاً عن كل أنواع الخدمات المعلنة عبر _services._dns-sd._udp، ثم يبحث عن كل نوع منها لمدة 10 ثوانٍ (AirPlay، RAOP، HTTP، الطابعات، وغيرها). الخدمة لا تظهر إلا بعد حلّ عنوانها بنجاح. البحث يحتاج إذن الشبكة المحلية من iOS.")
                    .font(.callout)
                    .foregroundColor(.secondary)
                HStack {
                    Button(state.isScanning ? "جارٍ البحث…" : "ابدأ البحث") {
                        Task { await ProbeRunner(state: state).runBonjour(seconds: 10) }
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(state.isScanning)
                    if state.bonjour.isSearching {
                        Button("إيقاف") {
                            state.bonjour.stop()
                        }
                        .buttonStyle(.bordered)
                    }
                }
                if !state.scanStatus.isEmpty {
                    Text(state.scanStatus).font(.callout).foregroundColor(.secondary)
                }
            }
            Section("أنواع الخدمات المعلنة (DNS-SD) (\(state.discoveredServiceTypes.count))") {
                if state.discoveredServiceTypes.isEmpty {
                    Text("لم يُسرد أي نوع بعد — شغّل البحث لسرد الأنواع المعلنة أولاً.")
                        .font(.callout)
                        .foregroundColor(.secondary)
                }
                ForEach(state.discoveredServiceTypes, id: \.self) { type in
                    Text(type)
                        .font(.callout)
                        .monospaced()
                }
            }
            Section("الخدمات المكتشفة (\(state.bonjour.services.count))") {
                if state.bonjour.services.isEmpty {
                    Text("لا خدمات بعد — شغّل البحث.")
                        .font(.callout)
                        .foregroundColor(.secondary)
                }
                ForEach(state.bonjour.services) { service in
                    VStack(alignment: .leading, spacing: 4) {
                        HStack {
                            Text(service.name)
                                .font(.headline)
                            if service.isDemo {
                                Text("تجريبي")
                                    .font(.caption)
                                    .foregroundColor(.orange)
                            }
                        }
                        Text(service.type)
                            .font(.caption)
                            .monospaced()
                            .foregroundColor(.secondary)
                        Text("\(service.host):\(service.port)")
                            .font(.callout)
                            .monospaced()
                    }
                }
            }
        }
        .navigationTitle("خدمات Bonjour")
    }
}
