import SwiftUI

// MARK: - ContentView
/// الشاشة الرئيسية — شبكة أيقونات كبيرة بخلفية سوداء وعناصر ذهبية،
/// بنفس روح تطبيق برمجة فورد، مع بطاقة تحذير صريحة في الأعلى تشرح
/// أن شبكة الشاشة غالباً شبكة CarPlay وليست بوابة CAN.

struct ContentView: View {
    @EnvironmentObject var state: ProbeState
    @State private var showDemoAlert = false

    private let columns = [
        GridItem(.flexible(), spacing: 16),
        GridItem(.flexible(), spacing: 16)
    ]

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    // بطاقة العنوان والحالة.
                    VStack(alignment: .leading, spacing: 6) {
                        Text("فاحص شاشة تورس")
                            .font(.title3)
                            .bold()
                            .foregroundColor(.gold)
                        if state.demoMode {
                            Text("وضع تجريبي — نتائج وهمية")
                                .font(.callout)
                                .foregroundColor(.orange)
                        } else if let ip = state.network.localIP {
                            Text("متصل — \(ip)")
                                .font(.callout)
                                .foregroundColor(.green)
                        } else {
                            Text("لم تُقرأ الشبكة بعد")
                                .font(.callout)
                                .foregroundColor(.secondary)
                        }
                        Button(state.demoMode ? "إلغاء الوضع التجريبي" : "تفعيل الوضع التجريبي") {
                            Task { @MainActor in
                                if state.demoMode {
                                    ProbeRunner(state: state).exitDemo()
                                } else {
                                    ProbeRunner(state: state).loadDemo()
                                }
                            }
                        }
                        .font(.callout)
                        .foregroundColor(.gold)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
                    .background(Color(white: 0.12))
                    .cornerRadius(20)

                    // بطاقة الصراحة — ماذا تفعل هذه الشبكة وماذا لا تفعل.
                    VStack(alignment: .leading, spacing: 8) {
                        Text("ماذا نفحص هنا؟")
                            .font(.headline)
                            .foregroundColor(.gold)
                        Text("شاشة تورس تبث شبكة Wi-Fi للآيفون لتشغيل CarPlay. هذه الشبكة غالباً شبكة وسائط (صوت وصورة) وليست بوابة لشبكة السيارة CAN، فلا تتوقع أكواد وحدات منها. هذا التطبيق تجربة قراءة فقط: يفحص ما هو متاح فعلاً على الشبكة — عناوين ومنافذ وخدمات — ويسجّل كل شيء في سجل لتصديره وتحليله. لا يخترع نتائج، ولا يحاول الدخول إلى أي خدمة، ولا يخمن كلمات مرور.")
                            .font(.callout)
                            .foregroundColor(.secondary)
                        Text("قبل الفحص: اتصل بشبكة الشاشة من إعدادات Wi-Fi في الآيفون أولاً.")
                            .font(.callout)
                            .bold()
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
                    .background(Color(white: 0.10))
                    .cornerRadius(20)

                    // زر الفحص الشامل.
                    Button {
                        Task { await ProbeRunner(state: state).runAll() }
                    } label: {
                        HStack {
                            Image(systemName: "play.circle.fill")
                            Text(state.isScanning ? "جارٍ الفحص…" : "فحص شامل")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.gold.opacity(0.2))
                        .foregroundColor(.gold)
                        .cornerRadius(16)
                    }
                    .disabled(state.isScanning)
                    if !state.scanStatus.isEmpty {
                        Text(state.scanStatus)
                            .font(.callout)
                            .foregroundColor(.secondary)
                    }

                    // شبكة الأيقونات.
                    LazyVGrid(columns: columns, spacing: 16) {
                        ForEach(ProbeDestination.allCases, id: \.self) { dest in
                            NavigationLink(value: dest) {
                                gridCell(for: dest)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("فاحص الشاشة")
            .navigationDestination(for: ProbeDestination.self) { dest in
                switch dest {
                case .network: NetworkView()
                case .discovery: DiscoveryView()
                case .ports: PortScanView()
                case .bonjour: BonjourView()
                case .http: HttpProbeView()
                case .log: ProbeLogView()
                case .summary: SummaryView()
                }
            }
        }
    }

    private func gridCell(for dest: ProbeDestination) -> some View {
        VStack(spacing: 10) {
            Image(systemName: dest.iconName)
                .font(.system(size: 38))
                .foregroundColor(.gold)
            Text(dest.rawValue)
                .font(.headline)
                .foregroundColor(.primary)
                .multilineTextAlignment(.center)
            Text(statusText(for: dest))
                .font(.caption)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity, minHeight: 130)
        .padding(.vertical, 12)
        .background(Color(white: 0.10))
        .cornerRadius(18)
    }

    private func statusText(for dest: ProbeDestination) -> String {
        switch dest {
        case .network:
            if let ip = state.network.localIP { return ip }
            return "لم تُقرأ بعد"
        case .discovery:
            return state.hosts.isEmpty ? "لم يُفحص بعد" : "\(state.hosts.count) جهازاً"
        case .ports:
            return state.portResults.isEmpty ? "لم يُفحص بعد" : "\(state.openPorts.count) مفتوحاً"
        case .bonjour:
            return state.bonjour.services.isEmpty ? "لم يُفحص بعد" : "\(state.bonjour.services.count) خدمة"
        case .http:
            return state.httpResults.isEmpty ? "لم يُفحص بعد" : "\(state.httpResults.count) نتيجة"
        case .log:
            return "\(state.log.entries.count) سطر"
        case .summary:
            return state.hasScanned ? "جاهزة" : "بعد الفحص"
        }
    }
}

// MARK: - Color.gold
extension Color {
    /// الذهبي المستخدم في الواجهة (مطابق لتطبيق برمجة فورد).
    static let gold = Color(red: 0.788, green: 0.663, blue: 0.0)
}
