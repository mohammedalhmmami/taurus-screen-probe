import SwiftUI

// MARK: - DiscoveryView
/// اكتشاف الأجهزة — مسح ping للنطاق المحلي، مع زمن الرد وطريقة الاكتشاف.
/// البوابة مميزة في القائمة.

struct DiscoveryView: View {
    @EnvironmentObject var state: ProbeState

    var body: some View {
        List {
            Section {
                Text("يمسح كل عناوين النطاق المحلي بـ ICMP ping (مهلة ثانية لكل عنوان)، ويسجّل كل عنوان ردّ وكل عنوان لم يرد في السجل. إن تعذّر ICMP على الجهاز يُستخدم اتصال TCP بالمنفذ 80 كبديل ويُسجَّل ذلك في النتيجة.")
                    .font(.callout)
                    .foregroundColor(.secondary)
                Button(state.isScanning ? "جارٍ المسح…" : "ابدأ المسح") {
                    Task { await ProbeRunner(state: state).runDiscovery() }
                }
                .buttonStyle(.borderedProminent)
                .disabled(state.isScanning)
                if !state.scanStatus.isEmpty {
                    Text(state.scanStatus).font(.callout).foregroundColor(.secondary)
                }
            }
            Section("الأجهزة التي ردّت (\(state.hosts.count))") {
                if state.hosts.isEmpty {
                    Text("لا أجهزة بعد — شغّل المسح.")
                        .font(.callout)
                        .foregroundColor(.secondary)
                }
                ForEach(state.hosts) { host in
                    VStack(alignment: .leading, spacing: 4) {
                        HStack {
                            Text(host.ip)
                                .font(.headline)
                                .monospaced()
                            if host.isGateway {
                                Text("البوابة")
                                    .font(.caption)
                                    .padding(.horizontal, 6)
                                    .padding(.vertical, 2)
                                    .background(Color.gold.opacity(0.25))
                                    .foregroundColor(.gold)
                                    .cornerRadius(8)
                            }
                            if state.likelyScreenDevice?.id == host.id {
                                Text("جهاز الشاشة المرجح")
                                    .font(.caption)
                                    .padding(.horizontal, 6)
                                    .padding(.vertical, 2)
                                    .background(Color.green.opacity(0.2))
                                    .foregroundColor(.green)
                                    .cornerRadius(8)
                            }
                            if host.isDemo {
                                Text("تجريبي")
                                    .font(.caption)
                                    .foregroundColor(.orange)
                            }
                            Spacer()
                            if let rtt = host.rttMs {
                                Text("\(String(format: "%.1f", rtt))ms")
                                    .font(.callout)
                                    .foregroundColor(.green)
                            }
                        }
                        Text("طريقة الاكتشاف: \(host.method)")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        if let hostname = host.hostname {
                            Text("اسم المضيف: \(hostname)")
                                .font(.caption)
                                .foregroundColor(.secondary)
                                .monospaced()
                        }
                    }
                }
            }
        }
        .navigationTitle("اكتشاف الأجهزة")
    }
}
