import SwiftUI

// MARK: - HttpProbeView
/// فحص HTTP — GET ‏/‏ على كل منفذ HTTP مفتوح، مع رمز الحالة والترويسات
/// وأول 2KB من الجسم (مقتطعاً).

struct HttpProbeView: View {
    @EnvironmentObject var state: ProbeState

    private var httpTargets: [PortResult] {
        state.openPorts.filter { state.httpPorts.contains($0.port) }
    }

    var body: some View {
        List {
            Section {
                Text("يرسل GET وHEAD للمسار الجذر وGET لمسارات شائعة (/api و/status و/info و/config و/about و/device و/system)، وOPTIONS لسرد الطرق المسموحة، إلى كل منفذ HTTP مفتوح وجده فحص المنافذ، ويسجّل رمز الحالة والترويسات وأول 2KB من الجسم فقط. لا يتبع روابط ولا يرسل بيانات.")
                    .font(.callout)
                    .foregroundColor(.secondary)
                Button(state.isScanning ? "جارٍ الفحص…" : "ابدأ فحص HTTP") {
                    Task { await ProbeRunner(state: state).runHttpProbe() }
                }
                .buttonStyle(.borderedProminent)
                .disabled(state.isScanning || httpTargets.isEmpty)
                if httpTargets.isEmpty {
                    Text("لا منافذ HTTP مفتوحة — شغّل فحص المنافذ أولاً.")
                        .font(.callout)
                        .foregroundColor(.secondary)
                }
            }
            Section("النتائج (\(state.httpResults.count))") {
                if state.httpResults.isEmpty {
                    Text("لا نتائج بعد.")
                        .font(.callout)
                        .foregroundColor(.secondary)
                }
                ForEach(state.httpResults) { result in
                    VStack(alignment: .leading, spacing: 6) {
                        HStack {
                            Text(result.url)
                                .font(.headline)
                                .monospaced()
                            Text(result.method)
                                .font(.caption)
                                .foregroundColor(.gold)
                            if result.isDemo {
                                Text("تجريبي")
                                    .font(.caption)
                                    .foregroundColor(.orange)
                            }
                        }
                        if let code = result.statusCode {
                            Text("رمز الحالة: \(code)")
                                .font(.callout)
                                .foregroundColor(code < 400 ? .green : .orange)
                        } else {
                            Text("بلا رد HTTP")
                                .font(.callout)
                                .foregroundColor(.red)
                        }
                        if let allowed = result.allowedMethods {
                            Text("الطرق المسموحة: \(allowed)")
                                .font(.caption)
                                .foregroundColor(.secondary)
                                .monospaced()
                        }
                        if let error = result.error {
                            Text("الخطأ: \(error)")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        if !result.headers.isEmpty {
                            Text("الترويسات:")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            ForEach(result.headers.prefix(10), id: \.0) { key, value in
                                Text("\(key): \(value)")
                                    .font(.caption)
                                    .monospaced()
                            }
                        }
                        if !result.bodyPrefix.isEmpty {
                            Text("أول الجسم (مقتطع 2KB):")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            Text(result.bodyPrefix)
                                .font(.caption)
                                .monospaced()
                        }
                    }
                }
            }
        }
        .navigationTitle("فحص HTTP")
    }
}
