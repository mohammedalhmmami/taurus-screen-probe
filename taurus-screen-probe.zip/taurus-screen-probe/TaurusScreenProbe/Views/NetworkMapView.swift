import SwiftUI

// MARK: - NetworkMapView
/// خارطة الشبكة — ملخص واحد يجمع كل ما وُجد: الواجهات والبوابة والأجهزة
/// والمنافذ المفتوحة والخدمات (Bonjour وUPnP وTLS) والتتبع والعقبات.
/// v1.1 — كل قسم يُبنى من النتائج المسجلة فقط؛ الفارغ يُعرض «لم يُوجد».

struct NetworkMapView: View {
    @EnvironmentObject var state: ProbeState

    var body: some View {
        List {
            Section("الواجهات") {
                if state.interfaces.isEmpty {
                    Text("لم تُقرأ واجهات بعد.")
                        .font(.callout)
                        .foregroundColor(.secondary)
                }
                ForEach(state.interfaces) { iface in
                    HStack {
                        Text(iface.name).font(.headline).monospaced()
                        Text(iface.kindLabelAr).font(.caption).foregroundColor(.secondary)
                        if iface.isActive {
                            Text("نشطة").font(.caption).foregroundColor(.gold)
                        }
                        Spacer()
                        Text(iface.ip ?? "—").font(.callout).monospaced().foregroundColor(.secondary)
                    }
                }
            }
            Section("البوابة") {
                if let gw = state.network.gateway {
                    HStack {
                        Text(gw).font(.headline).monospaced()
                        Spacer()
                        Text(state.network.gatewaySource.labelAr).font(.callout).foregroundColor(.secondary)
                    }
                } else {
                    Text("غير معروفة — حلّ البوابة لم يؤكد عنواناً.")
                        .font(.callout)
                        .foregroundColor(.secondary)
                }
                ForEach(state.gatewayCandidates) { candidate in
                    HStack {
                        Text(candidate.ip).monospaced()
                        Text(candidate.source).font(.caption).foregroundColor(.secondary)
                        Spacer()
                        Text(candidate.labelAr).foregroundColor(candidate.responded ? .green : .secondary)
                    }
                }
            }
            Section("الأجهزة (\(state.hosts.count))") {
                if state.hosts.isEmpty {
                    Text("لا أجهزة ردّت.")
                        .font(.callout)
                        .foregroundColor(.secondary)
                }
                ForEach(state.hosts) { host in
                    HStack {
                        Text(host.ip).font(.headline).monospaced()
                        if let hostname = host.hostname {
                            Text(hostname).font(.caption).foregroundColor(.secondary)
                        }
                        if state.likelyScreenDevice?.id == host.id {
                            Text("الشاشة المرجحة").font(.caption).foregroundColor(.green)
                        }
                        Spacer()
                        if let rtt = host.rttMs {
                            Text("\(String(format: "%.1f", rtt))ms").font(.callout).foregroundColor(.green)
                        }
                    }
                }
            }
            Section("المنافذ المفتوحة (\(state.openPorts.count))") {
                if state.openPorts.isEmpty {
                    Text("لا منافذ مفتوحة.")
                        .font(.callout)
                        .foregroundColor(.secondary)
                }
                ForEach(state.openPorts) { result in
                    HStack {
                        Text("\(result.host):\(result.port)").font(.headline).monospaced()
                        if let service = result.serviceName {
                            Text(service).font(.caption).foregroundColor(.gold)
                        }
                        Spacer()
                        if result.isDemo {
                            Text("تجريبي").font(.caption).foregroundColor(.orange)
                        }
                    }
                }
            }
            Section("الخدمات") {
                if state.bonjour.services.isEmpty && state.ssdpServices.isEmpty && state.tlsResults.isEmpty {
                    Text("لا خدمات مكتشفة (لا Bonjour ولا UPnP ولا TLS).")
                        .font(.callout)
                        .foregroundColor(.secondary)
                }
                ForEach(state.bonjour.services) { service in
                    HStack {
                        Image(systemName: "airplayaudio").foregroundColor(.gold)
                        Text(service.name).font(.callout)
                        Spacer()
                        Text("\(service.host):\(service.port)").font(.caption).monospaced().foregroundColor(.secondary)
                    }
                }
                ForEach(state.ssdpServices) { service in
                    HStack {
                        Image(systemName: "network").foregroundColor(.gold)
                        Text(service.server).font(.callout)
                        Spacer()
                        Text(service.sourceIP).font(.caption).monospaced().foregroundColor(.secondary)
                    }
                }
                ForEach(state.tlsResults) { cert in
                    HStack {
                        Image(systemName: "lock.shield").foregroundColor(.gold)
                        Text(cert.subject).font(.callout)
                        Spacer()
                        Text("\(cert.host):\(cert.port)").font(.caption).monospaced().foregroundColor(.secondary)
                    }
                }
            }
            Section("تتبع المسار (\(state.traceHops.count) قفزة)") {
                if state.traceHops.isEmpty {
                    Text("لم يُجرَ تتبع بعد.")
                        .font(.callout)
                        .foregroundColor(.secondary)
                }
                ForEach(state.traceHops) { hop in
                    HStack {
                        Text("\(hop.ttl)").font(.headline).monospaced()
                        Text(hop.statusAr).font(.callout).monospaced()
                        Spacer()
                        if let rtt = hop.rttMs {
                            Text("\(String(format: "%.1f", rtt))ms").font(.callout).foregroundColor(.green)
                        }
                    }
                }
            }
            Section("العقبات (\(state.obstacles.count))") {
                if state.obstacles.isEmpty {
                    Text("لا عقبات مسجلة.")
                        .font(.callout)
                        .foregroundColor(.secondary)
                }
                ForEach(state.obstacles) { obstacle in
                    VStack(alignment: .leading, spacing: 4) {
                        Text(obstacle.title).font(.headline)
                        Text("السبب: \(obstacle.cause)").font(.callout)
                        Text("الإصلاح: \(obstacle.fix)").font(.callout).foregroundColor(.green)
                    }
                }
            }
            Section {
                Button("إعادة الفحص الشامل") {
                    Task { await ProbeRunner(state: state).runAll() }
                }
                .buttonStyle(.borderedProminent)
                .disabled(state.isScanning)
            }
        }
        .navigationTitle("خارطة الشبكة")
    }
}
