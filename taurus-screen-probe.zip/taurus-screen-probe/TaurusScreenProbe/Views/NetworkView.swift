import SwiftUI
import UIKit

// MARK: - NetworkView
/// شاشة الشبكة الحالية — كل حقل يُعرض كما قرأته iOS، وما لا تستطيع
/// iOS كشفه يُعرض «غير متاح من iOS» بصراحة.
/// v1.1: سرد كل الواجهات مع الواجهة النشطة، وBSSID، ومرشحو البوابة مع
/// حالة ردّ كل منهم، وحالة إذن الشبكة المحلية مع زر فتح الإعدادات.

struct NetworkView: View {
    @EnvironmentObject var state: ProbeState

    var body: some View {
        List {
            Section("الشبكة الحالية") {
                row(label: "اسم الشبكة (SSID)", value: state.network.ssid ?? "غير متاح من iOS",
                    note: state.network.ssidAvailable ? nil : "iOS تمنع قراءة SSID بلا صلاحية Wi-Fi الخاصة")
                row(label: "BSSID (عنوان نقطة الوصول)", value: state.network.bssid ?? "غير متاح من iOS",
                    note: state.network.ssidAvailable ? nil : "بنفس قيد SSID أعلاه")
                row(label: "عنوان الآيفون", value: state.network.localIP ?? "غير مقروء")
                row(label: "قناع الشبكة", value: state.network.netmask ?? "غير مقروء")
                row(label: "البوابة", value: state.network.gateway ?? "غير متاحة",
                    note: state.network.gateway.map { _ in state.network.gatewaySource.labelAr })
                row(label: "خوادم DNS", value: state.network.dnsServers.isEmpty ? "غير مقروءة" : state.network.dnsServers.joined(separator: ", "))
                row(label: "نوع الاتصال", value: state.network.isWiFi ? "Wi-Fi" : "ليس Wi-Fi / غير متصل")
                if state.network.isDemo {
                    Text("وضع تجريبي — هذه شبكة وهمية وليست شبكة سيارة.")
                        .font(.callout)
                        .foregroundColor(.orange)
                }
            }
            Section("كل الواجهات (\(state.interfaces.count))") {
                if state.interfaces.isEmpty {
                    Text("لا واجهات مقروءة — أعد قراءة الشبكة بعد الاتصال بشبكة الشاشة.")
                        .font(.callout)
                        .foregroundColor(.secondary)
                }
                ForEach(state.interfaces) { iface in
                    VStack(alignment: .leading, spacing: 4) {
                        HStack {
                            Text(iface.name)
                                .font(.headline)
                                .monospaced()
                            Text(iface.kindLabelAr)
                                .font(.caption)
                                .foregroundColor(.secondary)
                            if iface.isActive {
                                Text("نشطة")
                                    .font(.caption)
                                    .padding(.horizontal, 6)
                                    .padding(.vertical, 2)
                                    .background(Color.gold.opacity(0.25))
                                    .foregroundColor(.gold)
                                    .cornerRadius(8)
                            }
                            Spacer()
                        }
                        Text("IP: \(iface.ip ?? "—") — القناع: \(iface.netmask ?? "—")")
                            .font(.callout)
                            .monospaced()
                            .foregroundColor(.secondary)
                    }
                }
            }
            Section("مرشحو البوابة") {
                if state.gatewayCandidates.isEmpty {
                    Text("لا مرشحين — اقرأ الشبكة أولاً.")
                        .font(.callout)
                        .foregroundColor(.secondary)
                }
                ForEach(state.gatewayCandidates) { candidate in
                    HStack {
                        Text(candidate.ip)
                            .font(.headline)
                            .monospaced()
                        Text(candidate.source)
                            .font(.caption)
                            .foregroundColor(.secondary)
                        Spacer()
                        Text(candidate.labelAr)
                            .font(.callout)
                            .foregroundColor(candidate.responded ? .green : .secondary)
                        if let rtt = candidate.rttMs {
                            Text("\(String(format: "%.1f", rtt))ms")
                                .font(.callout)
                                .foregroundColor(.green)
                        }
                    }
                }
                Text("البوابة المؤكدة هي أول مرشح يردّ بردّ مباشر (ping أو TCP:80). المرشح بلا ردّ يبقى تقديراً من النطاق فقط.")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            Section("إذن الشبكة المحلية") {
                HStack {
                    Text("الحالة")
                    Spacer()
                    Text(state.localNetworkPermission.labelAr)
                        .foregroundColor(state.localNetworkPermission == .denied ? .red : .secondary)
                }
                if let code = state.permissionErrorCode {
                    Text("رمز خطأ البحث: \(code)")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                Text("iOS لا توفر طريقة مباشرة لسؤال الإذن — الحالة هنا مستدلة من عمل البحث نفسه: «ممنوح» إن عمل البحث، و«مرفوض» إن فشل بخطأ إذن.")
                    .font(.caption)
                    .foregroundColor(.secondary)
                if state.localNetworkPermission == .denied {
                    Button("فتح إعدادات التطبيق") {
                        if let url = URL(string: UIApplication.openSettingsURLString) {
                            UIApplication.shared.open(url)
                        }
                    }
                    .buttonStyle(.bordered)
                }
            }
            Section("ماذا يعني هذا؟") {
                Text("البوابة هي غالباً عنوان الشاشة نفسها على الشبكة — فحصها أول هدف في أدوات الفحص. عنوان الآيفون والقناع يحددان نطاق المسح في اكتشاف الأجهزة.")
                    .font(.callout)
                    .foregroundColor(.secondary)
                Text("إن ظهر «غير متاح من iOS» لاسم الشبكة فهذا قيد من Apple وليس خللاً في التطبيق — الفحص يعمل بدونه.")
                    .font(.callout)
                    .foregroundColor(.secondary)
            }
            Section {
                Button("إعادة قراءة الشبكة") {
                    ProbeRunner(state: state).refreshNetwork()
                }
                .buttonStyle(.bordered)
            }
        }
        .navigationTitle("الشبكة الحالية")
        .onAppear {
            if state.network.localIP == nil && !state.demoMode {
                ProbeRunner(state: state).refreshNetwork()
            }
        }
    }

    private func row(label: String, value: String, note: String? = nil) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text(label).foregroundColor(.primary)
                Spacer()
                Text(value).foregroundColor(.secondary).monospaced()
            }
            if let note {
                Text(note).font(.caption).foregroundColor(.secondary)
            }
        }
    }
}
