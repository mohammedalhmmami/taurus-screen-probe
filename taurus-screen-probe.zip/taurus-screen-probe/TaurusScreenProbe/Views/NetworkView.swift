import SwiftUI

// MARK: - NetworkView
/// شاشة الشبكة الحالية — كل حقل يُعرض كما قرأته iOS، وما لا تستطيع
/// iOS كشفه يُعرض «غير متاح من iOS» بصراحة.

struct NetworkView: View {
    @EnvironmentObject var state: ProbeState

    var body: some View {
        List {
            Section("الشبكة الحالية") {
                row(label: "اسم الشبكة (SSID)", value: state.network.ssid ?? "غير متاح من iOS",
                    note: state.network.ssidAvailable ? nil : "iOS تمنع قراءة SSID بلا صلاحية Wi-Fi الخاصة")
                row(label: "عنوان الآيفون", value: state.network.localIP ?? "غير مقروء")
                row(label: "قناع الشبكة", value: state.network.netmask ?? "غير مقروء")
                row(label: "البوابة", value: state.network.gateway ?? "غير متاحة",
                    note: state.network.gateway.map { _ in state.network.gatewaySource.labelAr })
                row(label: "خوادم DNS", value: state.network.dnsServers.isEmpty ? "غير مقروءة" : state.network.dnsServers.joined(separator: ", "))
                row(label: "نوع الاتصال", value: state.network.isWiFi ? "Wi-Fi" : "ليس Wi-Fi / غير متصل")
                if state.network.isDemo {
                    Text("وضع تجريبي — هذه شبكة وهمية وليست شبكة سيارة.")
                        .font(.callout)
                        .foregroundColor(.orange)
                }
            }
            Section("ماذا يعني هذا؟") {
                Text("البوابة هي غالباً عنوان الشاشة نفسها على الشبكة — فحصها أول هدف في أدوات الفحص. عنوان الآيفون والقناع يحددان نطاق المسح في اكتشاف الأجهزة.")
                    .font(.callout)
                    .foregroundColor(.secondary)
                Text("إن ظهر «غير متاح من iOS» لاسم الشبكة فهذا قيد من Apple وليس خللاً في التطبيق — الفحص يعمل بدونه.")
                    .font(.callout)
                    .foregroundColor(.secondary)
            }
            Section {
                Button("إعادة قراءة الشبكة") {
                    ProbeRunner(state: state).refreshNetwork()
                }
                .buttonStyle(.bordered)
            }
        }
        .navigationTitle("الشبكة الحالية")
        .onAppear {
            if state.network.localIP == nil && !state.demoMode {
                ProbeRunner(state: state).refreshNetwork()
            }
        }
    }

    private func row(label: String, value: String, note: String? = nil) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text(label).foregroundColor(.primary)
                Spacer()
                Text(value).foregroundColor(.secondary).monospaced()
            }
            if let note {
                Text(note).font(.caption).foregroundColor(.secondary)
            }
        }
    }
}
