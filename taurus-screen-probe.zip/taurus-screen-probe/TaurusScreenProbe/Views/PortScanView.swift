import SwiftUI

// MARK: - PortScanView
/// فحص المنافذ — TCP على المنافذ الشائعة أو الكاملة (1–65535) للبوابة
/// ولكل جهاز ردّ، مع الحالة (مفتوح/مغلق/لا رد) ولافتة الخدمة واسمها
/// المعروف حيثما وردت.
/// v1.1: وضعان (سريع/كامل)، أسماء خدمات معروفة، وإحصاء المفحوص والمغلق
/// (في الوضع الكامل تُحفظ المفتوحة فقط).

struct PortScanView: View {
    @EnvironmentObject var state: ProbeState

    private var open: [PortResult] {
        state.portResults.filter { $0.state == .open }
    }

    private var closed: [PortResult] {
        state.portResults.filter { $0.state != .open }
    }

    var body: some View {
        List {
            Section {
                Text("الوضع السريع يفحص \(state.commonPorts.count) منفذاً شائعاً؛ الوضع الكامل يفحص كل المنافذ 1–65535 (قد يستغرق دقائق لكل هدف — استخدمه عند الحاجة فقط). المنفذ المفتوح يُقرأ ردّه الفوري (لافتة الخدمة). كل نتيجة تُسجَّل في السجل.")
                    .font(.callout)
                    .foregroundColor(.secondary)
                Picker("وضع الفحص", selection: $state.portScanMode) {
                    ForEach(PortScanMode.allCases, id: \.self) { mode in
                        Text(mode.labelAr).tag(mode)
                    }
                }
                .pickerStyle(.segmented)
                .disabled(state.isScanning)
                Button(state.isScanning ? "جارٍ الفحص…" : "ابدأ فحص المنافذ") {
                    Task { await ProbeRunner(state: state).runPortScan() }
                }
                .buttonStyle(.borderedProminent)
                .disabled(state.isScanning)
                if !state.scanStatus.isEmpty {
                    Text(state.scanStatus).font(.callout).foregroundColor(.secondary)
                }
                if state.portScannedCount > 0 {
                    Text("فُحص \(state.portScannedCount) منفذاً — \(open.count) مفتوحاً، \(state.portClosedCount) مغلقاً/بلا ردّ")
                        .font(.callout)
                        .foregroundColor(.secondary)
                }
            }
            Section("منافذ مفتوحة (\(open.count))") {
                if open.isEmpty {
                    Text("لا منافذ مفتوحة بعد — شغّل الفحص.")
                        .font(.callout)
                        .foregroundColor(.secondary)
                }
                ForEach(open) { result in
                    portRow(result, isOpen: true)
                }
            }
            Section("مغلقة / بلا رد (\(closed.count))") {
                if state.portScanMode == .full && closed.isEmpty && state.portScannedCount > 0 {
                    Text("في الوضع الكامل تُحفظ المفتوحة فقط — عدد المغلقة/بلا ردّ: \(state.portClosedCount).")
                        .font(.callout)
                        .foregroundColor(.secondary)
                }
                ForEach(closed) { result in
                    portRow(result, isOpen: false)
                }
            }
        }
        .navigationTitle("فحص المنافذ")
    }

    private func portRow(_ result: PortResult, isOpen: Bool) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text("\(result.host):\(result.port)")
                    .font(.headline)
                    .monospaced()
                if let service = result.serviceName {
                    Text(service)
                        .font(.caption)
                        .foregroundColor(.gold)
                }
                Spacer()
                Text(result.state.labelAr)
                    .font(.callout)
                    .foregroundColor(isOpen ? .green : .secondary)
                if result.isDemo {
                    Text("تجريبي")
                        .font(.caption)
                        .foregroundColor(.orange)
                }
            }
            if let banner = result.banner, !banner.isEmpty {
                Text("اللافتة:")
                    .font(.caption)
                    .foregroundColor(.secondary)
                Text(banner)
                    .font(.caption)
                    .monospaced()
                    .foregroundColor(.primary)
            }
        }
    }
}
