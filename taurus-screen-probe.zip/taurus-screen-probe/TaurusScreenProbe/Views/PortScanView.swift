import SwiftUI

// MARK: - PortScanView
/// فحص المنافذ — TCP على المنافذ الشائعة للبوابة ولكل جهاز ردّ،
/// مع الحالة (مفتوح/مغلق/لا رد) ولافتة الخدمة حيثما وردت.

struct PortScanView: View {
    @EnvironmentObject var state: ProbeState

    private var open: [PortResult] {
        state.portResults.filter { $0.state == .open }
    }

    private var closed: [PortResult] {
        state.portResults.filter { $0.state != .open }
    }

    var body: some View {
        List {
            Section {
                Text("يفحص \(state.commonPorts.count) منفذاً شائعاً على البوابة وعلى كل جهاز ردّ في اكتشاف الأجهزة. المنفذ المفتوح يُقرأ ردّه الفوري (لافتة الخدمة)؛ ولمنافذ HTTP يُرسل طلب GET بسيط. كل نتيجة — مفتوحاً كان أو مغلقاً — تُسجَّل في السجل.")
                    .font(.callout)
                    .foregroundColor(.secondary)
                Button(state.isScanning ? "جارٍ الفحص…" : "ابدأ فحص المنافذ") {
                    Task { await ProbeRunner(state: state).runPortScan() }
                }
                .buttonStyle(.borderedProminent)
                .disabled(state.isScanning)
                if !state.scanStatus.isEmpty {
                    Text(state.scanStatus).font(.callout).foregroundColor(.secondary)
                }
            }
            Section("منافذ مفتوحة (\(open.count))") {
                if open.isEmpty {
                    Text("لا منافذ مفتوحة بعد — شغّل الفحص.")
                        .font(.callout)
                        .foregroundColor(.secondary)
                }
                ForEach(open) { result in
                    portRow(result, isOpen: true)
                }
            }
            Section("مغلقة / بلا رد (\(closed.count))") {
                ForEach(closed) { result in
                    portRow(result, isOpen: false)
                }
            }
        }
        .navigationTitle("فحص المنافذ")
    }

    private func portRow(_ result: PortResult, isOpen: Bool) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text("\(result.host):\(result.port)")
                    .font(.headline)
                    .monospaced()
                Spacer()
                Text(result.state.labelAr)
                    .font(.callout)
                    .foregroundColor(isOpen ? .green : .secondary)
                if result.isDemo {
                    Text("تجريبي")
                        .font(.caption)
                        .foregroundColor(.orange)
                }
            }
            if let banner = result.banner, !banner.isEmpty {
                Text("اللافتة:")
                    .font(.caption)
                    .foregroundColor(.secondary)
                Text(banner)
                    .font(.caption)
                    .monospaced()
                    .foregroundColor(.primary)
            }
        }
    }
}
