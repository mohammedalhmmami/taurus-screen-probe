import SwiftUI

// MARK: - ProbeLogView
/// سجل الفحص الكامل — كل خطوة ونتيجتها الخام، مع تصدير نص + JSON
/// إلى Documents والمشاركة عبر ShareLink لإرساله إلى المطوّر.

struct ProbeLogView: View {
    @EnvironmentObject var state: ProbeState
    @State private var exportedURLs: (txt: URL, json: URL)?
    @State private var exportMessage: String?

    var body: some View {
        List {
            Section {
                Text("كل خطوة فحص تُسجَّل هنا بوقتها ونتيجتها الخام. صدّر السجل وأرسله للمطوّر لتحليل ما وُجد على شبكة الشاشة فعلاً.")
                    .font(.callout)
                    .foregroundColor(.secondary)
                HStack {
                    Button("تصدير السجل") {
                        if let urls = state.log.exportFiles() {
                            exportedURLs = urls
                            exportMessage = "حُفظ في الملفات: \(urls.txt.lastPathComponent)"
                            state.log.add(.success, category: "تصدير", message: "صُدّر السجل: \(urls.txt.lastPathComponent) + \(urls.json.lastPathComponent)")
                        } else {
                            exportMessage = "فشل حفظ ملف التصدير."
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(state.log.entries.isEmpty)
                    if let urls = exportedURLs {
                        ShareLink(item: urls.txt, preview: SharePreview("سجل فاحص الشاشة")) {
                            Label("مشاركة النص", systemImage: "square.and.arrow.up")
                        }
                        .buttonStyle(.bordered)
                        ShareLink(item: urls.json, preview: SharePreview("سجل فاحص الشاشة JSON")) {
                            Label("مشاركة JSON", systemImage: "square.and.arrow.up")
                        }
                        .buttonStyle(.bordered)
                    }
                }
                if let exportMessage {
                    Text(exportMessage).font(.caption).foregroundColor(.secondary)
                }
                Button("مسح السجل") {
                    state.log.clear()
                    exportedURLs = nil
                    exportMessage = nil
                }
                .buttonStyle(.bordered)
                .foregroundColor(.red)
                .disabled(state.log.entries.isEmpty)
            }
            Section("المدخلات (\(state.log.entries.count))") {
                if state.log.entries.isEmpty {
                    Text("السجل فارغ — شغّل أي فحص أولاً.")
                        .font(.callout)
                        .foregroundColor(.secondary)
                }
                ForEach(state.log.entries) { entry in
                    VStack(alignment: .leading, spacing: 4) {
                        HStack {
                            Text(entry.date.formatted(date: .omitted, time: .standard))
                                .font(.caption)
                                .monospaced()
                                .foregroundColor(.secondary)
                            Text(entry.level.labelAr)
                                .font(.caption)
                                .foregroundColor(levelColor(entry.level))
                            Text(entry.category)
                                .font(.caption)
                                .foregroundColor(.gold)
                            Spacer()
                        }
                        Text(entry.message)
                            .font(.callout)
                        if !entry.detail.isEmpty {
                            Text(entry.detail)
                                .font(.caption)
                                .foregroundColor(.secondary)
                                .monospaced()
                        }
                    }
                }
            }
        }
        .navigationTitle("السجل")
    }

    private func levelColor(_ level: ProbeLogLevel) -> Color {
        switch level {
        case .info: return .secondary
        case .success: return .green
        case .warning: return .orange
        case .error: return .red
        }
    }
}
