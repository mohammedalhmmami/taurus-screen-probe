import SwiftUI

// MARK: - SummaryView
/// الخلاصة — ملخص صريح: ما وُجد وما لم يوجد، وما يعنيه ذلك.
/// كل جملة مبنية على نتائج الفحص المسجلة فقط؛ لا استنتاج خارجها.

struct SummaryView: View {
    @EnvironmentObject var state: ProbeState

    var body: some View {
        List {
            Section("الخلاصة") {
                ForEach(Array(state.summaryStatements.enumerated()), id: \.offset) { _, statement in
                    HStack(alignment: .top, spacing: 10) {
                        Image(systemName: iconName(for: statement.kind))
                            .foregroundColor(color(for: statement.kind))
                        Text(statement.text)
                            .font(.callout)
                    }
                }
            }
            Section("الأرقام") {
                row(label: "أجهزة ردّت", value: "\(state.hosts.count)")
                row(label: "منافذ مفتوحة", value: "\(state.openPorts.count) من \(state.portResults.count) مفحوصاً")
                row(label: "خدمات Bonjour", value: "\(state.bonjour.services.count)")
                row(label: "نتائج HTTP", value: "\(state.httpResults.count)")
                row(label: "سطور السجل", value: "\(state.log.entries.count)")
            }
            Section {
                Button("إعادة الفحص الشامل") {
                    Task { await ProbeRunner(state: state).runAll() }
                }
                .buttonStyle(.borderedProminent)
                .disabled(state.isScanning)
            }
        }
        .navigationTitle("الخلاصة")
    }

    private func row(label: String, value: String) -> some View {
        HStack {
            Text(label).foregroundColor(.primary)
            Spacer()
            Text(value).foregroundColor(.secondary).monospaced()
        }
    }

    private func iconName(for kind: SummaryStatement.Kind) -> String {
        switch kind {
        case .fact: return "info.circle"
        case .conclusion: return "checkmark.circle"
        case .warning: return "exclamationmark.triangle"
        }
    }

    private func color(for kind: SummaryStatement.Kind) -> Color {
        switch kind {
        case .fact: return .secondary
        case .conclusion: return .green
        case .warning: return .orange
        }
    }
}
