import SwiftUI

// MARK: - SummaryView
/// الخلاصة — ملخص صريح: ما وُجد وما لم يوجد، وما يعنيه ذلك.
/// كل جملة مبنية على نتائج الفحص المسجلة فقط؛ لا استنتاج خارجها.

struct SummaryView: View {
    @EnvironmentObject var state: ProbeState

    var body: some View {
        List {
            Section("الخلاصة") {
                ForEach(Array(state.summaryStatements.enumerated()), id: \.offset) { _, statement in
                    HStack(alignment: .top, spacing: 10) {
                        Image(systemName: iconName(for: statement.kind))
                            .foregroundColor(color(for: statement.kind))
                        Text(statement.text)
                            .font(.callout)
                    }
                }
            }
            Section("العقبات (\(state.obstacles.count))") {
                if state.obstacles.isEmpty {
                    Text("لا عقبات مسجلة — كل خطوة فحص أجابت أو لم تُجرَ بعد.")
                        .font(.callout)
                        .foregroundColor(.secondary)
                }
                ForEach(state.obstacles) { obstacle in
                    VStack(alignment: .leading, spacing: 4) {
                        HStack {
                            Image(systemName: "exclamationmark.triangle")
                                .foregroundColor(.orange)
                            Text(obstacle.title)
                                .font(.headline)
                            if obstacle.isDemo {
                                Text("تجريبي")
                                    .font(.caption)
                                    .foregroundColor(.orange)
                            }
                        }
                        Text("الفئة: \(obstacle.category)")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        Text("السبب المحتمل: \(obstacle.cause)")
                            .font(.callout)
                        Text("الإصلاح المقترح: \(obstacle.fix)")
                            .font(.callout)
                            .foregroundColor(.green)
                    }
                }
            }
            Section("الأرقام") {
                row(label: "أجهزة ردّت", value: "\(state.hosts.count)")
                row(label: "منافذ مفتوحة", value: "\(state.openPorts.count) من \(state.portScannedCount) مفحوصاً")
                row(label: "خدمات Bonjour", value: "\(state.bonjour.services.count)")
                row(label: "خدمات UPnP/SSDP", value: "\(state.ssdpServices.count)")
                row(label: "شهادات TLS", value: "\(state.tlsResults.count)")
                row(label: "قفزات التتبع", value: "\(state.traceHops.count)")
                row(label: "نتائج HTTP", value: "\(state.httpResults.count)")
                row(label: "عقبات", value: "\(state.obstacles.count)")
                row(label: "سطور السجل", value: "\(state.log.entries.count)")
            }
            Section {
                Button("إعادة الفحص الشامل") {
                    Task { await ProbeRunner(state: state).runAll() }
                }
                .buttonStyle(.borderedProminent)
                .disabled(state.isScanning)
            }
        }
        .navigationTitle("الخلاصة")
    }

    private func row(label: String, value: String) -> some View {
        HStack {
            Text(label).foregroundColor(.primary)
            Spacer()
            Text(value).foregroundColor(.secondary).monospaced()
        }
    }

    private func iconName(for kind: SummaryStatement.Kind) -> String {
        switch kind {
        case .fact: return "info.circle"
        case .conclusion: return "checkmark.circle"
        case .warning: return "exclamationmark.triangle"
        }
    }

    private func color(for kind: SummaryStatement.Kind) -> Color {
        switch kind {
        case .fact: return .secondary
        case .conclusion: return .green
        case .warning: return .orange
        }
    }
}
